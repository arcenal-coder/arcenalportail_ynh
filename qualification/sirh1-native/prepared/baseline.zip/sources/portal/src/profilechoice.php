<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);

/** Only an authenticated neutral selector is rendered; no business controller runs. */
function vigilanceProfileChoice(array $context): bool
{
    if (!$context['access']->grouped() || $context['profile']!==null) return false;
    $roles=$context['access']->account()['roles'];
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        if (($_POST['action']??'')!=='profile' || !is_string($_POST['csrf']??null) || !hash_equals($_SESSION['csrf'],$_POST['csrf']) || !is_string($_POST['profile']??null)) throw new DomainException('Sélection de profil non autorisée.');
        \Vigilance\SessionProfiles::choose($_SESSION,$roles,$_POST['profile']);
        header('Location: ?view=home',true,303); return true;
    }
    $e=static fn(string $value): string=>htmlspecialchars($value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    $labels=['admin'=>'Administration','rh'=>'RH','direction'=>'Direction','employee'=>'Équipier','qsse'=>'QSSE','rp'=>'RP','crp'=>'CRP','manager'=>'Manager','tutor'=>'Tuteur','candidate'=>'Candidat'];
    ?><!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Choisir un profil — VIGIlance</title><link rel="stylesheet" href="vigilance.css"><main class="content"><h1>Choisissez votre profil</h1><p>Vos droits sont vérifiés pour chaque action.</p><form method="post" action="?view=home"><input type="hidden" name="csrf" value="<?= $e($_SESSION['csrf']) ?>"><input type="hidden" name="action" value="profile"><label for="profile">Profil actif</label><select id="profile" name="profile"><?php foreach($roles as $role): ?><option value="<?= $e($role) ?>"><?= $e($labels[$role]) ?></option><?php endforeach; ?></select><button>Utiliser ce profil</button></form></main></html><?php
    return true;
}
