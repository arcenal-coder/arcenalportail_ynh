<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

final class AuthorizationUnavailable extends \RuntimeException
{
    public function __construct() { parent::__construct('Vérification des droits momentanément indisponible.'); }
}

final class ProtectedJson
{
    /** Local root-managed data only; never accept a URL, link or app-writable parent. */
    public static function read(string $path): string
    {
        if ($path==='' || $path[0]!=='/' || str_contains($path,"\0") || str_contains($path,'/../') || str_contains($path,'/./')) throw new AuthorizationUnavailable();
        $directory=dirname($path);
        while (true) {
            $stat=@lstat($directory);
            if (!$stat || ($stat['mode']&0170000)!==0040000 || $stat['uid']!==0 || ($stat['mode']&0022)!==0) throw new AuthorizationUnavailable();
            if ($directory==='/') break;
            $directory=dirname($directory);
        }
        $before=@lstat($path);
        if (!$before || !self::fileStat($before)) throw new AuthorizationUnavailable();
        $stream=@fopen($path,'rb');
        if ($stream===false) throw new AuthorizationUnavailable();
        try {
            $stat=fstat($stream);
            if (!$stat || !self::fileStat($stat) || $stat['dev']!==$before['dev'] || $stat['ino']!==$before['ino']) throw new AuthorizationUnavailable();
            $body=stream_get_contents($stream,1048577);
            if ($body===false || strlen($body)>1048576) throw new AuthorizationUnavailable();
            return $body;
        } finally { fclose($stream); }
    }

    private static function fileStat(array $stat): bool
    {
        return ($stat['mode']&0170000)===0100000 && $stat['uid']===0 && ($stat['mode']&0777)===0640 && $stat['size']<=1048576;
    }

    public static function decode(string $body): array
    {
        try { $value=json_decode($body,true,32,JSON_THROW_ON_ERROR); }
        catch (\JsonException $error) { throw new AuthorizationUnavailable(); }
        if (!is_array($value)) throw new AuthorizationUnavailable();
        return $value;
    }
}
