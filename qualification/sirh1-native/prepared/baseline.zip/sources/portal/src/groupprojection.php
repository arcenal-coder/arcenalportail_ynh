<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

final class GroupProjection
{
    public const ROLES=['admin','rh','direction','employee','qsse','rp','crp','manager','tutor'];
    private \Closure $reader;
    private \Closure $clock;
    private int $generation=0;

    /** Reader/clock injection is a server-side test seam, never a configuration flag. */
    public function __construct(private readonly array $config, ?callable $reader=null, ?callable $clock=null)
    {
        $this->reader=\Closure::fromCallable($reader??[ProtectedJson::class,'read']);
        $this->clock=\Closure::fromCallable($clock??static function(): array {
            $boot=@file_get_contents('/proc/sys/kernel/random/boot_id');
            if ($boot===false) throw new AuthorizationUnavailable();
            return ['utc'=>time(),'monotonic'=>(int)floor(hrtime(true)/1000000000),'boot_id'=>trim($boot)];
        });
    }

    public static function uuid(mixed $value): bool
    {
        return is_string($value) && preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/D',$value)===1;
    }

    public function read(): array
    {
        try {
            $raw=($this->reader)((string)($this->config['group_bindings_path']??''));
            $bindings=ProtectedJson::decode($raw);
            $this->bindings($bindings);
            $document=ProtectedJson::decode(($this->reader)((string)($this->config['group_projection_path']??'')));
            $this->document($document,$bindings,hash('sha256',$raw));
            $this->generation=$document['generation'];
            return $document+['bindings'=>$bindings];
        } catch (AuthorizationUnavailable $error) { throw $error; }
        catch (\Throwable $error) { throw new AuthorizationUnavailable(); }
    }

    private function bindings(array $value): void
    {
        if (($value['schema']??'')!=='vigilance.group-bindings/v1'
            || ($value['instance']??null)!==($this->config['app_instance']??null)
            || !is_string($value['instance']??null) || !preg_match('/^[a-z][a-z0-9_]*$/D',$value['instance'])
            || ($value['company_id']??null)!==($this->config['company_id']??1)
            || !is_int($value['company_id']) || $value['company_id']<1
            || !is_array($value['groups']??null) || !$value['groups']) throw new AuthorizationUnavailable();
        foreach ($value['groups'] as $role=>$groups) {
            if (!in_array($role,self::ROLES,true) || !is_array($groups) || !array_is_list($groups)) throw new AuthorizationUnavailable();
            foreach ($groups as $group) {
                if (!is_string($group) || !preg_match('/^[a-z0-9][-a-z0-9_.]*$/D',$group) || in_array($group,['all_users','visitors'],true)) throw new AuthorizationUnavailable();
            }
            if (count($groups)!==count(array_unique($groups))) throw new AuthorizationUnavailable();
        }
        if (!is_array($value['legacy_bindings']??null)) throw new AuthorizationUnavailable();
        foreach ($value['legacy_bindings'] as $uid=>$uuid) {
            Identity::validate((string)$uid);
            if (!self::uuid($uuid)) throw new AuthorizationUnavailable();
        }
    }

    private function document(array $doc,array $bindings,string $digest): void
    {
        if (($doc['schema']??'')!=='vigilance.group-projection/v1' || ($doc['status']??'')!=='ok'
            || ($doc['instance']??null)!==$bindings['instance'] || ($doc['company_id']??null)!==$bindings['company_id']
            || ($doc['config_sha256']??null)!==$digest || !is_int($doc['generation']??null) || $doc['generation']<max(1,$this->generation)
            || !is_array($doc['users']??null) || !is_array($doc['groups']??null)) throw new AuthorizationUnavailable();
        $now=($this->clock)();
        if (!self::uuid($doc['boot_id']??null) || $doc['boot_id']!==($now['boot_id']??null)) throw new AuthorizationUnavailable();
        foreach (['utc','monotonic'] as $kind) {
            $start=$doc['collected_'.$kind]??null;
            $current=$now[$kind]??null;
            if (!is_int($start) || !is_int($current) || $start<0 || $current<$start || $current-$start>=60) throw new AuthorizationUnavailable();
        }
        if (($doc['expires_utc']??null)!==$doc['collected_utc']+60) throw new AuthorizationUnavailable();
        $seen=[];
        foreach ($doc['users'] as $uid=>$entry) {
            Identity::validate((string)$uid);
            if (!self::uuid($entry) || isset($seen[$entry])) throw new AuthorizationUnavailable();
            $seen[$entry]=true;
        }
        $selected=array_unique(array_merge(...array_values($bindings['groups'])));
        foreach ($doc['groups'] as $group=>$members) {
            if (!in_array($group,$selected,true)) continue;
            if (isset($doc['users'][$group]) || !is_array($members) || !array_is_list($members)) throw new AuthorizationUnavailable();
            foreach ($members as $member) if (!is_string($member) || !isset($doc['users'][$member])) throw new AuthorizationUnavailable();
            if (count($members)!==count(array_unique($members))) throw new AuthorizationUnavailable();
        }
    }

    public function roles(array $doc,string $uid): array
    {
        if (!isset($doc['users'][$uid])) throw new \DomainException('Identité sans habilitation actuelle.');
        $roles=[];
        foreach ($doc['bindings']['groups'] as $role=>$groups) {
            foreach ($groups as $group) if (in_array($uid,$doc['groups'][$group]??[],true)) { $roles[]=$role; break; }
        }
        return $roles;
    }
}
