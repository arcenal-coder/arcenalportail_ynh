<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

/** Policy contract for future resources, not an implementation of L05/L06 routes. */
final class ResourcePolicy
{
    public function __construct(private readonly Access $access) {}

    public function allows(string $resource,string $operation,array $stored): bool
    {
        if (!$this->access->grouped()) return false;
        $account=$this->access->account();
        if (($stored['company_id']??null)!==$this->access->company || !is_string($stored['owner_uid']??null) || !GroupProjection::uuid($stored['owner_entry_uuid']??null)) return false;
        $owner=$stored['owner_uid']===$this->access->uid && hash_equals($account['entry_uuid'],$stored['owner_entry_uuid']);
        if ($resource==='piece') {
            if (in_array($operation,['read','download'],true)) return ($owner && ($this->access->has('employee') || $this->access->has('candidate'))) || $this->access->has('rh') || $this->access->has('admin') || $this->access->has('direction');
            if ($operation==='replace') return $owner && $this->access->has('employee');
            if ($operation==='initial_deposit') return $owner && $this->access->has('candidate');
        }
        if ($resource==='vault' && in_array($operation,['list','read','download'],true)) return $owner && $this->access->has('employee');
        if ($resource==='vault.payslip' && $operation==='deposit') {
            $recipient=$this->access->recipient($stored['owner_uid']);
            return $this->access->has('rh') && $recipient!==null
                && in_array('employee',$recipient['roles'],true)
                && hash_equals($recipient['entry_uuid'],$stored['owner_entry_uuid']);
        }
        return false;
    }
}
