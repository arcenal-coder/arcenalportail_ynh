<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

final class Authorization
{
    private ?GroupProjection $source;

    public function __construct(private readonly Database $db,private readonly array $config=[],?GroupProjection $source=null)
    {
        $this->source=$source;
    }

    public function grouped(int $company): bool
    {
        $state=$this->db->rows('SELECT * FROM authorization_state WHERE company_id=?',[$company])[0]??null;
        $mode=$this->config['authorization_mode']??'legacy';
        if (!in_array($mode,['legacy','groups'],true)) throw new AuthorizationUnavailable();
        if ($state && ($mode!=='groups' || $state['instance']!==($this->config['app_instance']??null))) throw new AuthorizationUnavailable();
        if ($mode==='groups' && !$state) throw new AuthorizationUnavailable();
        return $state!==null;
    }

    private function source(): GroupProjection
    {
        return $this->source??=new GroupProjection($this->config);
    }

    public function document(int $company): array
    {
        if ($company!==(int)($this->config['company_id']??1)) throw new AuthorizationUnavailable();
        return $this->source()->read();
    }

    /** Existing account/identity must be bound; legacy roles never authorize a group-mode role. */
    public function account(int $company,string $uid,bool $includeDisabled=false): array
    {
        Identity::validate($uid);
        $row=$this->db->rows('SELECT * FROM account WHERE company_id=? AND uid=?',[$company,$uid])[0]??null;
        if (!$row || (!$includeDisabled && !(int)$row['enabled'])) throw new \DomainException('Votre accès doit être autorisé par un administrateur.');
        $row['roles']=json_decode($row['roles'],true,16,JSON_THROW_ON_ERROR);
        $row['teams']=json_decode($row['teams'],true,16,JSON_THROW_ON_ERROR);
        if (!$this->grouped($company)) return $row;
        $doc=$this->document($company);
        $uuid=$doc['users'][$uid]??null;
        $binding=$this->db->rows('SELECT entry_uuid FROM account_source_identity WHERE company_id=? AND uid=?',[$company,$uid])[0]['entry_uuid']??null;
        if ($uuid===null || $binding===null || !hash_equals($binding,$uuid)) throw new \DomainException('Identité sans habilitation actuelle.');
        $roles=$this->source()->roles($doc,$uid);
        $candidate=$this->db->rows('SELECT c.stage FROM candidature c JOIN person p ON p.id=c.person_id WHERE c.company_id=? AND p.account_uid=?',[$company,$uid])[0]??null;
        if ($candidate && $candidate['stage']!=='accepted') {
            $roles=array_values(array_diff($roles,['employee']));
            $roles[]='candidate';
        }
        $row['roles']=(int)$row['enabled']===1?$roles:[];
        $row['awaiting_employee']=$candidate!==null && $candidate['stage']==='accepted' && !in_array('employee',$roles,true);
        $row['entry_uuid']=$uuid;
        return $row;
    }

    public function observe(int $company,string $uid): void
    {
        if (!$this->grouped($company)) { Identity::observe($this->db,$company,$uid); return; }
        $doc=$this->document($company);
        if (!isset($doc['users'][$uid])) throw new \DomainException('Identité sans habilitation actuelle.');
        $this->db->transaction(function () use ($company,$uid,$doc): void {
            $other=$this->db->rows('SELECT uid FROM account_source_identity WHERE company_id=? AND entry_uuid=? AND uid<>?',[$company,$doc['users'][$uid],$uid]);
            if ($other) throw new \DomainException('Association d’identité à vérifier.');
            $created=$this->db->execute('INSERT OR IGNORE INTO account(company_id,uid) VALUES (?,?)',[$company,$uid]);
            if ($created) $this->bind($company,$uid,$doc['users'][$uid]);
        });
    }

    private function bind(int $company,string $uid,string $uuid): void
    {
        $this->db->execute('INSERT INTO account_source_identity(company_id,uid,entry_uuid,bound_at) VALUES (?,?,?,?)',[$company,$uid,$uuid,gmdate('c')]);
    }

    /** Explicit local maintenance operation; does not modify directory or historical roles. */
    public function activate(): array
    {
        if (($this->config['authorization_mode']??null)!=='groups') throw new AuthorizationUnavailable();
        $company=(int)($this->config['company_id']??1);
        $admin=false; $bound=0;
        $this->db->transaction(function () use ($company,&$admin,&$bound): void {
            // Read after acquiring the SQLite write lock, not before a possible wait.
            $doc=$this->document($company);
            foreach ($doc['bindings']['groups'] as $groups) foreach ($groups as $group) if (!array_key_exists($group,$doc['groups'])) throw new AuthorizationUnavailable();
            $this->db->guard('authorization.activate',function () use ($company,$doc): void {
                // Bindings, identity and enabled administrator must come from one
                // still-current projection. A changed source requires a fresh retry.
                if ($this->document($company)!==$doc) throw new AuthorizationUnavailable();
            });
            foreach ($this->db->rows('SELECT uid,enabled FROM account WHERE company_id=?',[$company]) as $account) {
                $uid=$account['uid']; $expected=$doc['users'][$uid]??null;
                if ($expected===null) continue;
                $current=$this->db->rows('SELECT entry_uuid FROM account_source_identity WHERE company_id=? AND uid=?',[$company,$uid])[0]['entry_uuid']??null;
                if ($current!==null && $current!==$expected) continue;
                if ($current===null && ($doc['bindings']['legacy_bindings'][$uid]??null)!==$expected) continue;
                if ($current===null) { $this->bind($company,$uid,$expected); $bound++; }
                if ((int)$account['enabled']===1 && in_array('admin',$this->source()->roles($doc,$uid),true)) $admin=true;
            }
            if (!$admin) throw new \DomainException('Administrateur habilité requis avant activation.');
            $state=$this->db->rows('SELECT instance FROM authorization_state WHERE company_id=?',[$company])[0]??null;
            if ($state && $state['instance']!==$doc['instance']) throw new AuthorizationUnavailable();
            $this->db->execute('INSERT OR IGNORE INTO authorization_state(company_id,instance,activated_at) VALUES (?,?,?)',[$company,$doc['instance'],gmdate('c')]);
            $this->db->audit($company,'maintenance','authorization.activate',(string)$company,1);
        });
        return ['activated'=>true,'bound'=>$bound];
    }

    public function eligible(int $company,string $uid): ?array
    {
        try {
            $account=$this->account($company,$uid);
            return $account['roles']?$account:null;
        } catch (\DomainException $error) { return null; }
    }

    public function guard(int $company,string $uid,?string $profile): void
    {
        if ($profile===null || !$this->grouped($company)) return;
        $this->db->guard($company.'|'.$uid.'|'.$profile,function () use ($company,$uid,$profile): void {
            $doc=$this->document($company);
            $binding=$this->db->rows('SELECT entry_uuid FROM account_source_identity WHERE company_id=? AND uid=?',[$company,$uid])[0]['entry_uuid']??null;
            if ($binding===null || ($doc['users'][$uid]??null)!==$binding) throw new \DomainException('Habilitation retirée.');
            // Workflow state/veto may intentionally change in this transaction.
            // Its original authorization is checked by the service; source rights
            // must remain valid even when the actor just accepted their offer.
            if ($profile!=='candidate' && !in_array($profile,$this->source()->roles($doc,$uid),true)) throw new \DomainException('Habilitation retirée.');
        });
    }

    public function accounts(int $company): array
    {
        $rows=$this->db->rows('SELECT * FROM account WHERE company_id=? ORDER BY uid',[$company]);
        if (!$this->grouped($company)) return $rows;
        // Validate even an empty roster; a failed source is not an empty directory.
        $this->document($company);
        foreach ($rows as &$row) {
            try { $roles=$this->account($company,$row['uid'],true)['roles']; }
            catch (\DomainException $error) { $roles=[]; }
            $row['roles']=json_encode($roles,JSON_THROW_ON_ERROR);
        }
        unset($row);
        return $rows;
    }

    public function bootstrap(int $company,string $uid): void
    {
        $doc=$this->document($company);
        if (!in_array('admin',$this->source()->roles($doc,$uid),true)) throw new \DomainException('Administrateur habilité requis.');
        foreach ($this->accounts($company) as $account) if ((int)$account['enabled']===1 && in_array('admin',json_decode($account['roles'],true),true)) throw new \DomainException('Un administrateur existe déjà.');
        $this->db->transaction(function () use ($company,$uid,$doc): void {
            $existing=$this->db->rows('SELECT uid FROM account WHERE company_id=? AND uid=?',[$company,$uid]);
            $pin=$this->db->rows('SELECT entry_uuid FROM account_source_identity WHERE company_id=? AND uid=?',[$company,$uid])[0]['entry_uuid']??null;
            if ($existing && $pin===null && ($doc['bindings']['legacy_bindings'][$uid]??null)!==$doc['users'][$uid]) throw new \DomainException('Association d’identité à vérifier.');
            if ($pin!==null && $pin!==$doc['users'][$uid]) throw new \DomainException('Association d’identité à vérifier.');
            $this->db->execute('INSERT OR IGNORE INTO account(company_id,uid) VALUES (?,?)',[$company,$uid]);
            if ($pin===null) $this->bind($company,$uid,$doc['users'][$uid]);
            $this->db->execute('UPDATE account SET enabled=1,revision=revision+1 WHERE company_id=? AND uid=?',[$company,$uid]);
            $this->db->audit($company,'maintenance','account.bootstrap',$uid,1);
        });
    }
}
