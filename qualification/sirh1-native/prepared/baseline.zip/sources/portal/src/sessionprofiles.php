<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

final class SessionProfiles
{
    public static function resolve(array &$session,array $roles,bool $grouped,string $method): ?string
    {
        $current=$session['profile']??null;
        if ($current!==null && !in_array($current,$roles,true)) {
            unset($session['profile']);
            if ($grouped) {
                $session['profile_choice_required']=true;
                $session['csrf']=bin2hex(random_bytes(32));
                if ($method==='POST') throw new \DomainException('Profil révoqué. Sélectionnez un profil autorisé.');
            }
            $current=null;
        }
        if ($current!==null) return $current;
        if ($grouped && (!empty($session['profile_choice_required']) || count($roles)>1)) return null;
        return $session['profile']=$roles[0]??null;
    }

    public static function choose(array &$session,array $roles,string $selected,bool $rotate=true): void
    {
        if (!in_array($selected,$roles,true)) throw new \DomainException('Profil non autorisé.');
        $session['profile']=$selected;
        unset($session['profile_choice_required']);
        if ($rotate) $session['csrf']=bin2hex(random_bytes(32));
    }
}
