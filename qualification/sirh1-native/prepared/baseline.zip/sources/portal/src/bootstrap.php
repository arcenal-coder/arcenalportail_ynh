<?php
// SPDX-License-Identifier: GPL-3.0-or-later
require_once __DIR__.'/load.php';

function vigilanceBootstrap(?\Vigilance\GroupProjection $projection=null): array
{
    vigilanceUploadLength((int)($_SERVER['CONTENT_LENGTH'] ?? 0),(string)ini_get('post_max_size'));
    if (is_file(__DIR__.'/../.maintenance')) throw new RuntimeException('Maintenance en cours.');
    $path = getenv('ARCENAL_PORTAL_CONFIG') ?: '/etc/arcenal-qsse-portal/config.php';
    $config = \Vigilance\Config::load($path);
    $uid = \Vigilance\Identity::fromServer($_SERVER, $config);
    $db = new \Vigilance\Database((string)($config['database_path'] ?? ''),$config,$projection);
    $db->checkSchema();
    $company = (int)($config['company_id'] ?? 1);
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['httponly'=>true,'secure'=>true,'samesite'=>'Strict']);
    session_start();
    if (($_SESSION['uid'] ?? '') !== $uid || ($_SESSION['company'] ?? null) !== $company) {
        session_regenerate_id(true);
        $_SESSION = ['uid'=>$uid,'company'=>$company,'csrf'=>bin2hex(random_bytes(32))];
    }
    try {
        $db->authority()->observe($company,$uid);
        $base = new \Vigilance\Access($db,$company,$uid);
        $account = $base->account();
        $profile=\Vigilance\SessionProfiles::resolve($_SESSION,$account['roles'],$base->grouped(),$_SERVER['REQUEST_METHOD']);
    } catch (\Vigilance\AuthorizationUnavailable $error) {
        unset($_SESSION['profile']); $_SESSION['profile_choice_required']=true;
        throw $error;
    } catch (DomainException $error) {
        unset($_SESSION['profile']); $_SESSION['profile_choice_required']=true;
        throw $error;
    }
    $access = new \Vigilance\Access($db,$company,$uid,$profile);
    $access->account();
    $qsse = ($config['qsse_enabled'] ?? true) && ($config['paired'] ?? true) && filter_var($config['gateway_url'] ?? '',FILTER_VALIDATE_URL) && parse_url($config['gateway_url'],PHP_URL_SCHEME) === 'https' && preg_match('/^[a-fA-F0-9]{64}$/D',$config['gateway_key'] ?? '');
    return ['config'=>$config,'uid'=>$uid,'db'=>$db,'access'=>$access,'account'=>$account,'profile'=>$profile,'qsse'=>(bool)$qsse];
}

function vigilanceUploadLength(int $length, string $setting): void
{
    $unit = strtolower(substr(trim($setting),-1));
    $factor = ['k'=>1024,'m'=>1048576,'g'=>1073741824][$unit] ?? 1;
    $maximum = (int)$setting*$factor;
    if ($maximum>0 && $length>$maximum) throw new \Vigilance\JourneyInput('Le transfert dépasse la limite du serveur. Vidéo : 1 Go maximum. Réduisez le fichier ou contactez votre administrateur.');
}

function vigilanceError(Throwable $error): void
{
    $known = $error instanceof DomainException || $error instanceof InvalidArgumentException;
    http_response_code($error instanceof DomainException ? 403 : ($known ? 422 : 503));
    header('Cache-Control: no-store');
    header("Content-Security-Policy: default-src 'none'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'");
    header('X-Content-Type-Options: nosniff');
    if (!$known) error_log('VIGIlance '.get_class($error));
    $message = $known ? $error->getMessage() : 'Le service est momentanément indisponible. Contactez votre administrateur.';
    print '<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VIGIlance</title><link rel="stylesheet" href="vigilance.css"><main class="content"><h1>VIGIlance</h1><p role="alert">'.htmlspecialchars($message,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p><a href="?view=home">Revenir à l’accueil</a><footer>Propulsé par ARCenal OS</footer></main></html>';
}
