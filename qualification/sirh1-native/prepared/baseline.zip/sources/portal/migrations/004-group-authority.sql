CREATE TABLE authorization_state (
 company_id INTEGER PRIMARY KEY REFERENCES company(id),
 instance TEXT NOT NULL,
 activated_at TEXT NOT NULL
);
CREATE TABLE account_source_identity (
 company_id INTEGER NOT NULL, uid TEXT NOT NULL, entry_uuid TEXT NOT NULL,
 bound_at TEXT NOT NULL,
 PRIMARY KEY(company_id,uid),
 UNIQUE(company_id,entry_uuid),
 FOREIGN KEY(company_id,uid) REFERENCES account(company_id,uid)
);
