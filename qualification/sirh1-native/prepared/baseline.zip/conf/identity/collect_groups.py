#!/usr/bin/python3
"""L04 local read-only publisher. Installed root-owned outside the PHP tree."""
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import signal
import stat
import tempfile
import time

SOCKET = 'ldapi://%2Fvar%2Frun%2Fslapd%2Fldapi'
BASE = 'dc=yunohost,dc=org'
PEER = 'gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth'
ROLES = {'admin','rh','direction','employee','qsse','rp','crp','manager','tutor'}
UID = re.compile(r'^[a-z0-9][-a-z0-9_.]*$')
UUID = re.compile(r'^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$')


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate_key')
        result[key] = value
    return result


def bindings(raw):
    value = json.loads(raw, object_pairs_hook=unique_object)
    if (value.get('schema') != 'vigilance.group-bindings/v1'
            or not re.fullmatch(r'[a-z][a-z0-9_]*', value.get('instance',''))
            or type(value.get('company_id')) is not int or value['company_id'] < 1
            or not isinstance(value.get('groups'),dict) or not value['groups']
            or set(value['groups']) - ROLES
            or not isinstance(value.get('legacy_bindings'),dict)):
        raise ValueError('invalid_bindings')
    for groups in value['groups'].values():
        if not isinstance(groups,list) or any(not isinstance(g,str) for g in groups) or len(groups)!=len(set(groups)):
            raise ValueError('invalid_group_list')
        if any(not UID.fullmatch(g) or g in {'all_users','visitors'} for g in groups):
            raise ValueError('invalid_group_name')
    for uid, entry in value['legacy_bindings'].items():
        if not UID.fullmatch(uid) or not isinstance(entry,str) or not UUID.fullmatch(entry):
            raise ValueError('invalid_identity_binding')
    return value


def root_directory(path):
    path = Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('invalid_path')
    for current in [path, *path.parents]:
        mode = current.lstat()
        if not stat.S_ISDIR(mode.st_mode) or mode.st_uid!=0 or mode.st_mode & 0o022:
            raise ValueError('untrusted_parent')


def root_read(path):
    path = Path(path)
    root_directory(path.parent)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_uid!=0 or stat.S_IMODE(before.st_mode)!=0o640:
        raise ValueError('untrusted_file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd,'rb') as stream:
        after = os.fstat(stream.fileno())
        if (after.st_ino,after.st_dev)!=(before.st_ino,before.st_dev):
            raise ValueError('file_replaced')
        raw = stream.read(1048577)
    if len(raw)>1048576:
        raise ValueError('oversize_file')
    return raw


def clock():
    return {'utc':int(time.time()),'monotonic':int(time.monotonic()),
            'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}


def ldap_entries():
    # Import only in the real publisher; unit tests need no local LDAP package.
    import ldap
    connection = ldap.initialize(SOCKET)
    connection.set_option(ldap.OPT_NETWORK_TIMEOUT,2)
    connection.set_option(ldap.OPT_TIMEOUT,2)
    try:
        connection.sasl_non_interactive_bind_s('EXTERNAL')
        if connection.whoami_s() != 'dn:' + PEER:
            raise ValueError('unexpected_directory_identity')
        users=connection.search_ext_s('ou=users,'+BASE,ldap.SCOPE_SUBTREE,
            '(&(objectclass=person)(!(uid=root))(!(uid=nobody)))',['uid','entryUUID'],timeout=2)
        groups=connection.search_ext_s('ou=groups,'+BASE,ldap.SCOPE_SUBTREE,
            '(objectclass=groupOfNamesYnh)',['cn','member'],timeout=2)
        return users,groups
    finally:
        connection.unbind_s()


def attributes(row):
    dn, values = row
    if not isinstance(dn,str) or not isinstance(values,dict):
        raise ValueError('incomplete_search')
    return {key.lower():[v.decode('utf-8') if isinstance(v,bytes) else v for v in entries]
            for key,entries in values.items()}


def project(config, raw, users_raw, groups_raw, started, generation):
    users={}
    for row in users_raw:
        item=attributes(row)
        if len(item.get('uid',[]))!=1 or len(item.get('entryuuid',[]))!=1:
            raise ValueError('incomplete_user')
        uid,entry=item['uid'][0],item['entryuuid'][0]
        if not UID.fullmatch(uid) or uid in {'root','nobody'} or not UUID.fullmatch(entry) or uid in users or entry in users.values():
            raise ValueError('invalid_user')
        users[uid]=entry
    selected={g for group_list in config['groups'].values() for g in group_list}
    groups={}
    for row in groups_raw:
        item=attributes(row)
        if len(item.get('cn',[]))!=1:
            raise ValueError('incomplete_group')
        name=item['cn'][0]
        if name not in selected:
            continue
        if name in users or name in groups:
            raise ValueError('primary_or_duplicate_group')
        members=[]
        for dn in item.get('member',[]):
            match=re.fullmatch(r'uid=([a-z0-9][-a-z0-9_.]*),ou=users,dc=yunohost,dc=org',dn)
            if not match or match[1] not in users:
                raise ValueError('unknown_group_member')
            members.append(match[1])
        if len(members)!=len(set(members)):
            raise ValueError('duplicate_member')
        groups[name]=members
    return {'schema':'vigilance.group-projection/v1','status':'ok',
            'instance':config['instance'],'company_id':config['company_id'],
            'config_sha256':hashlib.sha256(raw).hexdigest(),'generation':generation,
            'collected_utc':started['utc'],'collected_monotonic':started['monotonic'],
            'expires_utc':started['utc']+60,'boot_id':started['boot_id'],
            'users':users,'groups':groups}


def publish(document,path,gid,trust=root_directory):
    path=Path(path)
    trust(path.parent)
    if path.is_symlink():
        raise ValueError('symlink_target')
    fd,temporary=tempfile.mkstemp(prefix='.projection-',dir=path.parent)
    try:
        os.fchmod(fd,0o640)
        # No setuid or app-writable executable; only this root process sets its data group.
        os.fchown(fd,-1,gid)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            fd=None
            json.dump(document,stream,ensure_ascii=True,separators=(',',':'))
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary,path)
        directory=os.open(path.parent,os.O_RDONLY)
        try: os.fsync(directory)
        finally: os.close(directory)
    finally:
        if fd is not None: os.close(fd)
        if os.path.exists(temporary): os.unlink(temporary)


def collect(config,raw,reader=ldap_entries,now=clock,generation=None):
    started=now()
    generation=generation or time.monotonic_ns()
    try:
        users,groups=reader()
        result=project(config,raw,users,groups,started,generation)
        finished=now()
        if finished['boot_id']!=started['boot_id'] or not 0<=finished['monotonic']-started['monotonic']<8 or not 0<=finished['utc']-started['utc']<8:
            raise ValueError('collection_timeout')
        return result
    except Exception:
        return {'schema':'vigilance.group-projection/v1','status':'error',
                'instance':config['instance'],'company_id':config['company_id'],
                'config_sha256':hashlib.sha256(raw).hexdigest(),'generation':generation,
                'reason':'source_unavailable'}


@contextmanager
def publication_lock(directory,trust=root_directory):
    # Common to the timer and direct maintenance/restore invocations. Never
    # unlink this inode: a waiting/overlapping process must share the same lock.
    directory=Path(directory)
    trust(directory)
    fd=os.open(directory/'collector.lock',os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW,0o600)
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid() or stat.S_IMODE(info.st_mode)!=0o600:
            raise ValueError('untrusted_lock')
        fcntl.flock(fd,fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(fd)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',required=True)
    args=parser.parse_args()
    if os.geteuid()!=0: raise ValueError('root_execution_required')
    raw=root_read(args.config); config=bindings(raw)
    directory=Path('/etc/arcenal-vigilance')/config['instance']
    if Path(args.config)!=directory/'bindings.json': raise ValueError('unexpected_config_path')
    gid=pwd.getpwnam(config['instance']).pw_gid
    signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('deadline')))
    with publication_lock(directory):
        signal.alarm(8)
        try: result=collect(config,raw)
        finally: signal.alarm(0)
        publish(result,directory/'projection.json',gid)
    return 0 if result['status']=='ok' else 1


if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception: raise SystemExit('VIGIlance : collecte de droits indisponible.') from None
