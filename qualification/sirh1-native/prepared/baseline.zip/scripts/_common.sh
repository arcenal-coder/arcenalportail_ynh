#!/bin/bash

vigilance_configure() {
    chmod 750 "$install_dir"
    local php_runtime="${php_version:-${phpversion:-8.2}}"
    local branding_domain
    # The app subdomain may have no logo; use YunoHost's configured main domain.
    branding_domain=$(yunohost domain main-domain --output-as json | php"$php_runtime" -r '
        $data=json_decode(stream_get_contents(STDIN),true);
        $domain=is_array($data)?($data["current_main_domain"]??""):"";
        if(!is_string($domain)||!preg_match("/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/iD",$domain))exit(1);
        echo $domain;
    ') || ynh_die "Impossible de déterminer le domaine principal YunoHost."
    chmod 700 "$data_dir"
    chown -R "$app:$app" "$data_dir"
    ARCENAL_PORTAL_CONFIG="$install_dir/config.php" \
        VIGILANCE_DATA_DIR="$data_dir" VIGILANCE_COMPANY="${company_name:-Entreprise}" \
        VIGILANCE_INITIAL_ADMIN="${initial_admin:-}" \
        VIGILANCE_APP_INSTANCE="$app" \
        VIGILANCE_BRANDING_ORIGIN="https://$branding_domain" \
        VIGILANCE_MAIL_FROM="$app@$domain" \
        VIGILANCE_PUBLIC_URL="https://$domain${path_url%/}/" \
        php"$php_runtime" "$install_dir/bin/configure.php"
    chown "$app:$app" "$install_dir/config.php"
    chown "$app:$app" "$install_dir/application-settings.php"
    # Migrations are performed before opening the new application, never on web requests.
    ynh_exec_as_app env ARCENAL_PORTAL_CONFIG="$install_dir/config.php" \
        php"$php_runtime" "$install_dir/bin/manage.php" migrate
    vigilance_mail_schedule
    vigilance_groups_install
}

vigilance_mail_schedule() {
    local php_runtime="${php_version:-${phpversion:-8.2}}"
    ynh_config_add --template="journey-mail.cron" --destination="/etc/cron.d/$app-journey-mail"
    chown root:root "/etc/cron.d/$app-journey-mail"
    chmod 644 "/etc/cron.d/$app-journey-mail"
}

vigilance_groups_install() {
    install -d -m 0755 -o root -g root "/usr/local/libexec/arcenal-vigilance" "/usr/local/libexec/arcenal-vigilance/$app"
    install -d -m 0755 -o root -g root "/etc/arcenal-vigilance"
    install -d -m 0750 -o root -g "$app" "/etc/arcenal-vigilance/$app"
    ynh_config_add --template="identity/collect_groups.py" --destination="/usr/local/libexec/arcenal-vigilance/$app/collect_groups.py"
    chown root:root "/usr/local/libexec/arcenal-vigilance" "/usr/local/libexec/arcenal-vigilance/$app" "/usr/local/libexec/arcenal-vigilance/$app/collect_groups.py"
    chmod 755 "/usr/local/libexec/arcenal-vigilance" "/usr/local/libexec/arcenal-vigilance/$app" "/usr/local/libexec/arcenal-vigilance/$app/collect_groups.py"
    ynh_config_add --template="identity/managed" --destination="/etc/arcenal-vigilance/$app/.managed"
    chown root:root "/etc/arcenal-vigilance"
    chmod 755 "/etc/arcenal-vigilance"
    chown "root:$app" "/etc/arcenal-vigilance/$app" "/etc/arcenal-vigilance/$app/.managed"
    chmod 750 "/etc/arcenal-vigilance/$app"
    chmod 640 "/etc/arcenal-vigilance/$app/.managed"
    ynh_config_add --template="identity/groups.service" --destination="/etc/systemd/system/$app-groups.service"
    ynh_config_add --template="identity/groups.timer" --destination="/etc/systemd/system/$app-groups.timer"
    systemctl daemon-reload
    ynh_systemctl --service="$app-groups.timer" --action=enable
    ynh_systemctl --service="$app-groups.timer" --action=start
    # No binding file is invented. The condition skips collection until configured.
}

vigilance_groups_refresh() {
    ynh_safe_rm "/etc/arcenal-vigilance/$app/projection.json"
    if test -f "/etc/arcenal-vigilance/$app/bindings.json"; then
        chown "root:$app" "/etc/arcenal-vigilance/$app" "/etc/arcenal-vigilance/$app/bindings.json"
        chmod 750 "/etc/arcenal-vigilance/$app"
        chmod 640 "/etc/arcenal-vigilance/$app/bindings.json"
        if ! python3 "/usr/local/libexec/arcenal-vigilance/$app/collect_groups.py" \
            --config "/etc/arcenal-vigilance/$app/bindings.json"; then
            local php_runtime="${php_version:-${phpversion:-8.2}}"
            ynh_exec_as_app env ARCENAL_PORTAL_CONFIG="$install_dir/config.php" \
                php"$php_runtime" "$install_dir/bin/manage.php" auth-require-source
        fi
    fi
}
