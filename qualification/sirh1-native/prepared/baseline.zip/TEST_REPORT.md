# VIGIlance — qualification native YunoHost

Statut : beta5 QUALIFIÉE et PROMUE EN PREVIEW le 20 octobre 2026 — niveau technique privé ARCenal 5, aucune note communautaire officielle attribuée. Recette cliente non exécutée.

## Beta6 — correctif L04 du 23 octobre 2026

- Défaut prouvé lors de la première tentative serveur : `ynh_config_add` écrivait dans `/usr/local/libexec/arcenal-vigilance/arcenalportail/` et `/etc/arcenal-vigilance/arcenalportail/` avant que les parents existent.
- Correctif `scripts/_common.sh` : création idempotente des parents (`0755 root:root`, puis répertoire d’instance `0750 root:arcenalportail`) avant tout template. Test `tests/native-l04/test_group_install.py` ajouté.
- Candidate corrigée SHA-256 `c9e3720398c5a92bb56ff7c21b4c44dee3c772ad97a5478a59d15e38116c4502` ; **28 tests Python PASS** localement.
- L04 exécuté sur le serveur actuel : upgrade beta6, activation groupes et réouverture effectués ; contrôles données/droits/projection/timer PASS, maintenance levée.
- **Cette candidate beta6 n’a pas passé la qualification native CI ni de publication catalogue dans cette phase.** Aucune réception humaine ; L04 non réceptionné.

## Beta5 — e-mails des workflows

- Candidate `1.1.0-beta5~ynh1`, révision paquet `8156e1e4b388ec7007edd967880368390e1e588b`, source applicative `c8597bcfd9eb7db1ca5bbdd9712738ea37464bb2`.
- CI source `39326009512` : RÉUSSI (services, HTTP, navigateur, e-mail historique, API et build ; 51 assertions e-mail des parcours,103 parcours,34 outils).
- Diagnostic isolé `39326035801` : RÉUSSI, installation racine et un upgrade. Worker sous UID applicatif, cron rendu/expéditeur, vrai MTA Postfix et réception Dovecot locale, contenu générique et absence de renvoi vérifiés. Artefact de diagnostic distinct, aucun niveau attribué par ce test réduit.
- Qualification complète [39326820575](https://github.com/arcenal-coder/arcenalportail_ynh/actions/runs/39326820575) : RÉUSSI, douze scénarios sur YunoHost12.1.41.2 amd64. Installations racine/sous-chemin/multi, sauvegarde/restauration, upgrade courant et cinq baselines (dont beta4 ynh2), changement d'URL et linter. Réception MTA/Dovecot locale et critères de confidentialité/absence de renvoi vrais après chacun des six upgrades ; `native_mail_verified=true`, critères privés1–5 satisfaits. Rapports communautaires originaux conservés ; exceptions de permissions limitées aux baselines beta1/beta2 réparées avec mode final750 prouvé.
- Catalogue [PR27](https://github.com/arcenal-coder/arcenal-systeme-catalogue/pull/27), CI39381417980 RÉUSSI, promotion officielle ciblée39381489061 RÉUSSI, publication Pages39381508946 RÉUSSI. Commit catalogue e30b8c7f46ebe6b0ddc73f5e0df61a5fbe12c665. Flux canonique, manifeste et miroir vérifiés : beta5/8156e1e/preview/working/level5. Seule VIGIlance change dans development/preview ; stable inchangé,23 tests catalogue réussis.
- Environnement de recette : nftables natif pour interdire l'egress SMTP externe durant le contrôle ; PostSRSd, Dovecot et Postfix existants démarrés uniquement dans le conteneur appci. Aucune installation de dépendance locale, aucun changement du serveur client.
- Historique : première CI source a révélé la détection PDO des transactions BEGIN IMMEDIATE avant PHP8.5, corrigée et testée ; premier contrôle MTA natif révélait iptables absent et PostSRSd désactivé dans l'image de recette. Les échecs ne sont pas requalifiés en succès.
- Déclenchement réel du planificateur cron et réception chez le client : NON_EXÉCUTÉS. Une acceptation MTA n'est pas une garantie de livraison externe. Recette cliente distincte ; aucun déploiement client exécuté.

La suite conserve l'historique de qualification beta3, pas le statut de la candidate beta5.

## Défaut de départ

Le niveau 0 déclaré dans le catalogue ARCenal bloque la mise à jour graphique : YunoHost 12.1 exige state=working et un niveau entier >=5. Les tests PHP/HTTP et le cycle avec helpers doublés ne prouvaient pas le cycle YunoHost réel.

## Exécution native initiale

GitHub Actions 38872994974, YunoHost 12.1.41.2 Bookworm stable, Incus isolé.

| Contrôle | Résultat |
|---|---|
| Syntaxe Bash | RÉUSSI |
| Linter du paquet initial | ÉCHEC : format de version, permissions de groupe data_dir, LICENSE et description anglaise obligatoire |
| Installation racine / sous-chemin | ÉCHEC : utilisateur de test johndoe absent de l'image, qui fournit package_checker |
| Multi-instance / sauvegarde-restauration / upgrades / changement d'URL | NON_EXÉCUTÉ : dépendance à l'installation réussie |

## Corrections préparées

Version conforme 1.1.0-beta3~ynh1, groupe privé __APP__:---, licence GPL complète sous LICENSE, DESCRIPTION.md, identité de test package_checker. Le manifeste annonce SSO mais pas une intégration LDAP directe encore absente. Le support de changement d'URL utilise le helper officiel ; aucune donnée métier ou permission n'est réinitialisée.

La suite standard n'exclut aucun scénario : installations racine/sous-chemin/multi, sauvegarde-restauration, upgrade courant et depuis beta1/beta2, changement d'URL, accès SSO et refus anonyme. Les rapports originaux et détails natifs sont archivés.

Les critères techniques ARCenal utilisent les fonctions natives de niveau 1 à 5 du checker épinglé f7d32cadac3cfced282decede024707fba9e6ec6, sur une copie des résultats où seuls les constats couplés d'absence du catalogue communautaire sont distingués. Les rapports communautaires originaux ne sont jamais modifiés. Un échec d'installation, de sécurité ou de conservation des données interdit la qualification.

## Résultat final

- Exécution réussie : https://github.com/arcenal-coder/arcenalportail_ynh/actions/runs/38885680216.
- Révision exacte : 39eaa3c66676a53ebbf99bab497a879e5d556f73, version 1.1.0-beta3~ynh1, YunoHost 12.1.41.2 amd64.
- Neuf scénarios réussis : linter, installations racine/sous-chemin/multi-instance, backup/restore, upgrade courant, upgrades beta1 et beta2, change_url.
- Les anciennes versions sont réparées explicitement avant leur upgrade ; leurs constats initiaux de permissions sont conservés et le mode final 750 est vérifié. Aucun échec de sécurité ni de conservation des données ignoré.
- Critères natifs 1 à 5 satisfaits sur copie selon la politique privée ci-dessus ; grade communautaire et rapports originaux conservés. 24 tests locaux des outils réussis.
- Catalogue : PR https://github.com/arcenal-coder/arcenal-systeme-catalogue/pull/23, CI 38906820986 et promotion ciblée 38906879611 réussies. Preview publie state=working, level=5, version et révision exactes ci-dessus ; 23 tests catalogue réussis.
- Recette de l'installation cliente non effectuée ici. Toute nouvelle révision exige une nouvelle qualification avant de reprendre ce niveau.
