<?php
// SPDX-License-Identifier: GPL-3.0-or-later
foreach (['configuration','database','identity','protectedjson','groupprojection','authorization','access','resourcepolicy','sessionprofiles','personservice','adminservice','branding','journeycontext','journeymail','candidateservice','contentservice','welcomeservice','uuid','affairservice','missionpdf','missionservice'] as $file) require_once __DIR__.'/'.$file.'.php';
