<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

final class AffairService
{
    public const STATUSES = ['active','closed','archived'];
    public const EXTERNAL_SYSTEMS = ['none','dolibarr'];

    public function __construct(private readonly Database $db, private readonly Access $access) {}

    public function canRead(): bool
    {
        return $this->access->has('direction') || $this->access->has('rh') || $this->access->has('manager');
    }

    public function canCreate(): bool
    {
        return $this->access->has('direction');
    }

    public function currentPerson(): ?array
    {
        return $this->db->rows('SELECT * FROM person WHERE company_id=? AND account_uid=?', [$this->access->company,$this->access->uid])[0] ?? null;
    }

    public function listing(bool $includeArchived = false): array
    {
        if (!$this->canRead()) throw new \DomainException('Affaires non accessibles.');
        $where = 'company_id=?';
        $params = [$this->access->company];
        if (!$includeArchived) $where .= " AND status<>'archived'";
        if ($this->access->has('manager') && !$this->access->has('direction') && !$this->access->has('rh')) {
            $person = $this->currentPerson();
            if ($person === null) return [];
            $where .= ' AND manager_person_id=?';
            $params[] = $person['id'];
        }
        return $this->db->rows('SELECT * FROM affair WHERE '.$where.' ORDER BY reference,id', $params);
    }

    public function get(string $id, bool $write = false): array
    {
        if (!Uuid::valid($id)) throw new \InvalidArgumentException('Affaire invalide.');
        $rows = $this->db->rows('SELECT * FROM affair WHERE company_id=? AND id=?', [$this->access->company,$id]);
        if (!$rows) throw new \DomainException('Affaire non accessible.');
        $affair = $rows[0];
        if ($write) {
            if ($this->access->has('direction')) return $affair;
            throw new \DomainException('Modification d’affaire non autorisée.');
        }
        if ($this->canRead()) {
            if ($this->access->has('rh') || $this->access->has('direction')) return $affair;
            $person = $this->currentPerson();
            if ($person !== null && $affair['manager_person_id'] === $person['id']) return $affair;
        }
        throw new \DomainException('Affaire non accessible.');
    }

    public function create(array $input): string
    {
        return $this->db->transaction(function () use ($input): string {
            if (!$this->canCreate()) throw new \DomainException('Création d’affaire réservée à la Direction.');
            $values = $this->validate($input);
            $reference = $this->db->rows('SELECT id FROM affair WHERE company_id=? AND reference=?', [$this->access->company,$values['reference']]);
            if ($reference) throw new \DomainException('Cette référence d’affaire existe déjà.');
            $id = Uuid::v4();
            $now = gmdate('c');
            $this->db->execute(
                'INSERT INTO affair(id,company_id,reference,label,client_label,site_label,manager_person_id,status,external_system,external_ref,nextcloud_folder_url,created_at,updated_at,revision) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)',
                [$id,$this->access->company,$values['reference'],$values['label'],$values['client_label'],$values['site_label'],$values['manager_person_id'],$values['status'],$values['external_system'],$values['external_ref'],$values['nextcloud_folder_url'],$now,$now]
            );
            $this->db->audit($this->access->company,$this->access->uid,'affair.create',$id,1);
            return $id;
        });
    }

    public function update(string $id, int $revision, array $input): void
    {
        $this->db->transaction(function () use ($id,$revision,$input): void {
            $before = $this->get($id, true);
            if ($revision < 1 || (int) $before['revision'] !== $revision) throw new \DomainException('L’affaire a changé. Rechargez-la avant de modifier.');
            $values = $this->validate($input, $before);
            if ($values['reference'] !== $before['reference'] && $this->db->rows('SELECT id FROM affair WHERE company_id=? AND reference=? AND id<>?', [$this->access->company,$values['reference'],$id])) {
                throw new \DomainException('Cette référence d’affaire existe déjà.');
            }
            $changed = $this->db->execute(
                'UPDATE affair SET reference=?,label=?,client_label=?,site_label=?,manager_person_id=?,status=?,external_system=?,external_ref=?,nextcloud_folder_url=?,updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?',
                [$values['reference'],$values['label'],$values['client_label'],$values['site_label'],$values['manager_person_id'],$values['status'],$values['external_system'],$values['external_ref'],$values['nextcloud_folder_url'],gmdate('c'),$this->access->company,$id,$revision]
            );
            if ($changed !== 1) throw new \DomainException('L’affaire a changé. Rechargez-la.');
            $this->db->audit($this->access->company,$this->access->uid,'affair.update',$id,$revision+1);
        });
    }

    /** Responsables possibles : personne active liée à un compte manager ou direction. */
    public function managerChoices(): array
    {
        $roles = [];
        foreach ($this->db->authority()->accounts($this->access->company) as $account) {
            if ((int) $account['enabled'] !== 1) continue;
            $decoded = json_decode((string) $account['roles'], true);
            if (is_array($decoded) && array_intersect($decoded,['manager','direction','rh'])) $roles[$account['uid']] = true;
        }
        $rows = $this->db->rows("SELECT id,first_name,last_name,account_uid FROM person WHERE company_id=? AND status='active' AND account_uid IS NOT NULL ORDER BY last_name,first_name", [$this->access->company]);
        return array_values(array_filter($rows, static fn(array $row): bool => isset($roles[$row['account_uid']])));
    }

    public function assertManagerScope(array $affair): void
    {
        if ($this->access->has('direction')) return;
        if (!$this->access->has('manager')) throw new \DomainException('Affaire non accessible.');
        $person = $this->currentPerson();
        if ($person === null || $affair['manager_person_id'] !== $person['id']) throw new \DomainException('Affaire non accessible.');
    }

    private function validate(array $input, ?array $before = null): array
    {
        $fields = ['reference','label','client_label','site_label','manager_person_id','status','external_system','external_ref','nextcloud_folder_url'];
        if (array_diff(array_keys($input), $fields)) throw new \InvalidArgumentException('Champ d’affaire non autorisé.');
        $values = [];
        foreach ($fields as $field) {
            $value = $input[$field] ?? '';
            if (!is_string($value) || mb_strlen($value) > 500 || preg_match('/[\x00-\x1F\x7F]/', $value)) throw new \InvalidArgumentException('Champ d’affaire invalide.');
            $values[$field] = trim($value);
        }
        if ($values['reference'] === '' || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._\/-]{0,39}$/D',$values['reference'])) throw new \InvalidArgumentException('Référence d’affaire invalide (40 caractères, lettres, chiffres, point, tiret, barre oblique).');
        if ($values['label'] === '' || mb_strlen($values['label']) > 180) throw new \InvalidArgumentException('Libellé d’affaire obligatoire (180 caractères maximum).');
        if (mb_strlen($values['client_label']) > 180 || mb_strlen($values['site_label']) > 180) throw new \InvalidArgumentException('Client ou site trop long.');
        if (!in_array($values['status'], self::STATUSES, true)) throw new \InvalidArgumentException('Statut d’affaire invalide.');
        if (!in_array($values['external_system'], self::EXTERNAL_SYSTEMS, true)) throw new \InvalidArgumentException('Source d’affaire invalide.');
        if ($values['external_ref'] !== '' && mb_strlen($values['external_ref']) > 120) throw new \InvalidArgumentException('Référence externe trop longue.');
        if ($values['external_system'] === 'none' && $values['external_ref'] !== '') throw new \InvalidArgumentException('Une référence externe exige une source Dolibarr.');
        $values['external_ref'] = $values['external_ref'] === '' ? null : $values['external_ref'];
        $values['nextcloud_folder_url'] = $values['nextcloud_folder_url'] === '' ? null : self::externalUrl($values['nextcloud_folder_url']);
        $values['manager_person_id'] = $values['manager_person_id'] === '' ? null : $values['manager_person_id'];
        if ($values['manager_person_id'] !== null) {
            if (!Uuid::valid($values['manager_person_id'])) throw new \InvalidArgumentException('Responsable d’affaire invalide.');
            $person = $this->db->rows("SELECT account_uid FROM person WHERE company_id=? AND id=? AND status='active'", [$this->access->company,$values['manager_person_id']]);
            if (!$person || !$person[0]['account_uid']) throw new \InvalidArgumentException('Le responsable d’affaire doit être une personne active liée à un compte.');
            $account = $this->db->authority()->eligible($this->access->company,(string) $person[0]['account_uid']);
            if ($account === null || !array_intersect($account['roles'],['manager','direction','rh'])) throw new \InvalidArgumentException('Le responsable d’affaire doit disposer d’un profil Manager, Direction ou RH.');
        }
        return $values;
    }

    public static function externalUrl(string $value): string
    {
        if (strlen($value) > 2048 || preg_match('/[\x00-\x20\x7F]/',$value)) throw new \InvalidArgumentException('Lien externe invalide.');
        $parts = parse_url($value);
        if (!is_array($parts) || filter_var($value,FILTER_VALIDATE_URL)===false || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) {
            throw new \InvalidArgumentException('Seuls les liens HTTPS sans identifiants sont acceptés.');
        }
        // Fail closed: opaque query/fragment values can carry bearer credentials.
        // Nextcloud/public sharing routes grant rights through the path itself.
        $path = rawurldecode(rawurldecode((string)($parts['path'] ?? '')));
        if (isset($parts['query']) || isset($parts['fragment']) || preg_match('~/(?:s|share|sharing)(?:/|$)|/public\.php(?:/|$)|[\x00-\x1F\x7F]~i',$path)) {
            throw new \InvalidArgumentException('Utilisez un lien HTTPS de dossier ou document authentifié, sans paramètres, fragment ni lien de partage public.');
        }
        return $value;
    }
}
