<?php
// SPDX-License-Identifier: GPL-3.0-or-later

function vigilanceApplication(array $context, string $view): void
{
    extract($context, EXTR_SKIP);
    $people = new \Vigilance\PersonService($db,$access);
    $admin = new \Vigilance\AdminService($db,$access);
    $missions = new \Vigilance\MissionService($db,$access);
    $affairs = new \Vigilance\AffairService($db,$access);
    $branding = new \Vigilance\Branding($db->directory.'/branding',(string)($config['branding_origin'] ?? ''));
    if ($view === 'logo') {
        $image = $branding->image();
        if ($image !== null) {
            header('Content-Type: '.$image['mime']);
            header('Content-Length: '.strlen($image['body']));
            header('Content-Security-Policy: default-src \'none\'; sandbox');
            print $image['body'];
            return;
        }
        $logo = $admin->company()['logo'];
        if (!preg_match('/^[a-f0-9]{64}\.(png|jpg|webp)$/D',$logo)) throw new DomainException('Logo non disponible.');
        $path = $db->directory.'/logos/'.$logo;
        if (!is_file($path)) throw new DomainException('Logo non disponible.');
        header('Content-Type: '.(['png'=>'image/png','jpg'=>'image/jpeg','webp'=>'image/webp'][pathinfo($logo,PATHINFO_EXTENSION)]));
        header('Content-Security-Policy: default-src \'none\'; sandbox');
        readfile($path);
        return;
    }
    if ($view === 'mission-order' || $view === 'mission-order-history') {
        $document = $missions->orderDocument((int)($_GET['id'] ?? 0),$view === 'mission-order-history');
        header('Content-Type: application/pdf');
        header('Content-Length: '.(string)filesize($document['path']));
        header('Content-Disposition: attachment; filename="'.($view==='mission-order-history'?'historique-':'').basename($document['filename']).'"');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        readfile($document['path']);
        return;
    }
    if ($view === 'mission-resource') {
        $document = $missions->resourceForDownload((int)($_GET['id'] ?? 0));
        header('Content-Type: '.$document['mime']);
        header('Content-Length: '.(string)filesize($document['path']));
        header('Content-Disposition: attachment; filename="'.basename($document['filename']).'"');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        readfile($document['path']);
        return;
    }
    if ($view === 'mission-draft') {
        $document = $missions->draftPdf((string)($_GET['id'] ?? ''),isset($_GET['assignment'])&&is_string($_GET['assignment'])?$_GET['assignment']:null);
        header('Content-Type: application/pdf');
        header('Content-Length: '.strlen($document['body']));
        header('Content-Disposition: inline; filename="'.basename($document['filename']).'"');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        print $document['body'];
        return;
    }
    if ($view === 'planning-export') {
        $filters = vigilancePlanningFilters($_GET);
        $rows = $missions->planning($filters['from'],$filters['to'],$filters['person'],$filters['affair'],$filters['site']);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="planning-'.gmdate('Ymd').'.csv"');
        print "\xEF\xBB\xBF";
        $out = fopen('php://output','wb');
        if ($out === false) throw new \RuntimeException('Export indisponible.');
        fputcsv($out,['Date','Début','Fin','Pause (min)','Équipier','Mission','Référence','Affaire','Site','État','Publié'],';','"','\\');
        foreach ($rows as $row) {
            fputcsv($out,array_map('vigilanceCsvCell',[$row['day'],$row['starts_at'],$row['ends_at'],(string)$row['break_minutes'],$row['person_name'],$row['mission_title'],$row['mission_reference'],$row['affair_reference'],$row['site_label'],vigilanceAssignmentState($row['state']),$row['unpublished']?'Non':'Oui']),';','"','\\');
        }
        fclose($out);
        return;
    }
    $labels = ['employee'=>'Équipier','rh'=>'RH','manager'=>'Manager','direction'=>'Direction','admin'=>'Administration','qsse'=>'QSSE','crp'=>'CRP','tutor'=>'Tuteur','candidate'=>'Candidat','rp'=>'RP'];
    $statuses = ['candidate'=>'Candidat','onboarding'=>'En intégration','active'=>'Actif','leaving'=>'En sortie','archived'=>'Archivé'];
    $error = '';
    $notice = $_SESSION['notice'] ?? '';
    unset($_SESSION['notice']);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'],$_POST['csrf'])) throw new DomainException('Formulaire expiré.');
        try {
            $successMessage = 'Enregistrement effectué.';
            $action = $_POST['action'] ?? '';
            $destination = '?view=home';
            if ($action === 'profile') {
                $selected = $_POST['profile'] ?? '';
                if (!is_string($selected) || !in_array($selected,$access->account()['roles'],true)) throw new DomainException('Profil non autorisé.');
                \Vigilance\SessionProfiles::choose($_SESSION,$access->account()['roles'],$selected,$access->grouped());
            } elseif ($action === 'person') {
                $input = array_diff_key($_POST,array_flip(['action','csrf','id','revision']));
                $id = $_POST['id'] ?? '';
                if (!is_string($id)) throw new InvalidArgumentException('Dossier invalide.');
                if ($id === '') $id = $people->create($input);
                else $people->update($id,(int)($_POST['revision'] ?? 0),$input);
                $destination = '?view=person&id='.rawurlencode($id);
            } elseif ($action === 'company') {
                $admin->rename((string)($_POST['name'] ?? ''),(int)($_POST['revision'] ?? 0));
                $destination = '?view=settings';
            } elseif ($action === 'branding-refresh') {
                $access->require('admin');
                $refreshed = $branding->resolve(true);
                if (!$refreshed['enabled']) throw new InvalidArgumentException('La source du logo YunoHost n’est pas configurée pour cette application.');
                $successMessage = $refreshed['error'] ? 'La synchronisation YunoHost est indisponible. L’application reste accessible.' : ($refreshed['available'] ? 'Le logo YunoHost a été vérifié.' : 'Aucun logo exploitable n’est déclaré dans YunoHost.');
                $destination = '?view=settings';
            } elseif ($action === 'account') {
                if (!is_array($_POST['roles'] ?? [])) throw new InvalidArgumentException('Rôles invalides.');
                $teams = array_values(array_filter(array_map('trim',explode(',',(string)($_POST['teams'] ?? ''))),static fn($team) => $team !== ''));
                $mail = $_POST['notification_email'] ?? null;
                if ($mail !== null && !is_string($mail)) throw new InvalidArgumentException('Adresse e-mail invalide.');
                $admin->updateAccount((string)($_POST['uid'] ?? ''),(int)($_POST['revision'] ?? 0),$_POST['roles'] ?? [],$teams,isset($_POST['enabled']),isset($_POST['directory']),$mail);
                $destination = '?view=settings';
            } elseif ($action === 'affair') {
                $input = array_intersect_key($_POST,array_flip(['reference','label','client_label','site_label','manager_person_id','status','external_system','external_ref','nextcloud_folder_url']));
                $id = is_string($_POST['id'] ?? null) ? (string)$_POST['id'] : '';
                if ($id === '') { $id = $affairs->create($input); $successMessage = 'Affaire créée.'; }
                else { $affairs->update($id,(int)($_POST['revision'] ?? 0),$input); $successMessage = 'Affaire enregistrée.'; }
                $destination = '?view=affair&id='.rawurlencode($id);
            } elseif ($action === 'mission') {
                $id = is_string($_POST['id'] ?? null) ? (string)$_POST['id'] : '';
                $input = vigilanceMissionInput($_POST);
                if ($id === '') { $id = $missions->create($input); $successMessage = 'Mission créée en brouillon.'; }
                else { $missions->update($id,(int)($_POST['revision'] ?? 0),$input); $successMessage = 'Mission enregistrée. Publiez-la pour la rendre visible aux équipiers.'; }
                $destination = '?view=mission-edit&id='.rawurlencode($id);
            } elseif ($action === 'mission-publish') {
                $id = (string)($_POST['id'] ?? '');
                $missions->publish($id,(int)($_POST['revision'] ?? 0));
                $successMessage = 'Mission publiée. Les équipiers dont l’empreinte a changé sont notifiés.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mission-accept') {
                $id = (string)($_POST['mission_id'] ?? '');
                $missions->accept((string)($_POST['assignment_id'] ?? ''),($_POST['acknowledged'] ?? '') === 'yes',(string)($_POST['version_id'] ?? ''),(string)($_POST['content_hash'] ?? ''));
                $successMessage = 'Mission acceptée. Votre ordre de mission est disponible.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mission-refuse') {
                $id = (string)($_POST['mission_id'] ?? '');
                $missions->refuse((string)($_POST['assignment_id'] ?? ''),(string)($_POST['reason'] ?? ''),(string)($_POST['version_id'] ?? ''),(string)($_POST['content_hash'] ?? ''));
                $successMessage = 'Refus enregistré. Le manager et la Direction sont notifiés.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mission-cancel') {
                $id = (string)($_POST['id'] ?? '');
                $missions->cancel($id,(int)($_POST['revision'] ?? 0),(string)($_POST['reason'] ?? ''));
                $successMessage = 'Mission annulée. Les ordres de mission émis sont annulés.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mission-close') {
                $id = (string)($_POST['id'] ?? '');
                $missions->close($id,(int)($_POST['revision'] ?? 0),(string)($_POST['note'] ?? ''));
                $successMessage = 'Mission clôturée.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mission-resource') {
                $id = (string)($_POST['id'] ?? '');
                $upload = $_FILES['document'] ?? [];
                if (($upload['error'] ?? -1) !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'] ?? '')) throw new InvalidArgumentException('Document invalide ou non transmis.');
                $missions->addInternalResource($id,(int)($_POST['revision'] ?? 0),(string)($_POST['title'] ?? ''),($_POST['required_reading'] ?? '') === 'yes',(string)$upload['tmp_name'],(string)($upload['name'] ?? ''));
                $successMessage = 'Document ajouté. Publiez une nouvelle version pour le rendre visible aux équipiers.';
                $destination = '?view=mission-edit&id='.rawurlencode($id);
            } elseif ($action === 'mission-resource-remove') {
                $id = (string)($_POST['id'] ?? '');
                $missions->removeResource($id,(int)($_POST['revision'] ?? 0),(int)($_POST['resource_id'] ?? 0));
                $successMessage = 'Document retiré de la mission.';
                $destination = '?view=mission-edit&id='.rawurlencode($id);
            } elseif ($action === 'mission-read') {
                $id = (string)($_POST['mission_id'] ?? '');
                $missions->markResourceRead((string)($_POST['assignment_id'] ?? ''),(int)($_POST['resource_id'] ?? 0));
                $successMessage = 'Lecture du document enregistrée.';
                $destination = '?view=mission&id='.rawurlencode($id);
            } elseif ($action === 'mail-retry') {
                (new \Vigilance\JourneyMail($db))->retryFailed($access);
                $destination = '?view=settings';
            } elseif ($action === 'logo') {
                $access->require('admin');
                $upload = $_FILES['logo'] ?? [];
                if (($upload['error'] ?? -1) !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'] ?? '') || (int)($upload['size'] ?? 0) > 2097152) throw new InvalidArgumentException('Logo invalide ou supérieur à 2 Mo.');
                $admin->setLogo(file_get_contents($upload['tmp_name']),(int)($_POST['revision'] ?? 0));
                $destination = '?view=settings';
            } else throw new InvalidArgumentException('Action inconnue.');
            $_SESSION['notice'] = $successMessage;
            header('Location: '.$destination,true,303);
            return;
        } catch (DomainException | InvalidArgumentException $failure) {
            http_response_code($failure instanceof DomainException ? 403 : 422);
            $error = $failure->getMessage();
        }
    }
    $company = $admin->company();
    $brandingStatus = $branding->resolve();
    $hasBrandLogo = $brandingStatus['available'] || $company['logo'] !== '';
    $isRh = $access->has('rh');
    $isManager = $access->has('manager');
    $isEmployee = $access->has('employee');
    $isAdmin = $access->has('admin');
    $isDirection = $access->has('direction');
    $canDirectory = (int)$access->account()['directory'] === 1 || $isRh || $isManager;
    $canQsse = $qsse && ($access->has('qsse') || $access->has('crp'));
    $person = null;
    $listing = null;
    $affair = null;
    $affairList = null;
    $affairManagers = [];
    $canCreateAffair = false;
    $mission = null;
    $missionManageView = false;
    $missionPeople = [];
    $missionAffairs = [];
    $planningRows = [];
    $planningPeople = [];
    $planningAffairs = [];
    $planningFilters = vigilancePlanningFilters([]);
    $agenda = [];
    $query = is_string($_GET['q'] ?? '') ? ($_GET['q'] ?? '') : '';
    if (in_array($view,['people','directory'],true)) {
        if ($view === 'people' && !$isRh && !$isManager) throw new DomainException('Liste non autorisée.');
        $listing = $people->listing($query,(int)($_GET['page'] ?? 1),$view === 'directory');
    } elseif ($view === 'person') {
        $person = $people->get((string)($_GET['id'] ?? ''),($_GET['directory'] ?? '') === '1');
    } elseif ($view === 'new') {
        $access->require('rh');
        $person = array_fill_keys(\Vigilance\PersonService::FIELDS,'');
        $person['status'] = 'candidate';
    } elseif ($view === 'mine') {
        $person = $people->mine();
    } elseif ($view === 'settings') {
        $access->require('admin');
        $accounts = $admin->accounts();
        $mailStatus = (new \Vigilance\JourneyMail($db))->status($access);
    } elseif ($view === 'affairs') {
        $affairList = $affairs->listing();
        $canCreateAffair = $affairs->canCreate();
    } elseif ($view === 'affair') {
        $affairId = is_string($_GET['id'] ?? null) ? (string)$_GET['id'] : '';
        if ($affairId === '') {
            if (!$affairs->canCreate()) throw new DomainException('Création d’affaire non autorisée.');
            $affair = ['id'=>'','reference'=>'','label'=>'','client_label'=>'','site_label'=>'','manager_person_id'=>'','status'=>'active','external_system'=>'none','external_ref'=>'','nextcloud_folder_url'=>'','revision'=>0];
            $canCreateAffair = true;
        } else {
            $affair = $affairs->get($affairId);
            $canCreateAffair = $affairs->canCreate();
        }
        $affairManagers = $canCreateAffair ? $affairs->managerChoices() : [];
    } elseif ($view === 'planning') {
        $planningFilters = vigilancePlanningFilters($_GET);
        $planningRows = $missions->planning($planningFilters['from'],$planningFilters['to'],$planningFilters['person'],$planningFilters['affair'],$planningFilters['site']);
        if ($missions->canManage() || $isRh) {
            $planningPeople = $missions->peopleChoices();
            $planningAffairs = $missions->affairChoices();
        }
    } elseif ($view === 'agenda') {
        $agenda = $missions->workerMissions();
    } elseif ($view === 'mission') {
        $missionId = (string)($_GET['id'] ?? '');
        $missionManageView = $missions->canManage() || $isRh;
        $mission = $missionManageView ? $missions->getManagement($missionId) : $missions->getEmployee($missionId);
    } elseif ($view === 'mission-edit') {
        if (!$missions->canManage()) throw new DomainException('Gestion des missions non autorisée.');
        $missionId = (string)($_GET['id'] ?? '');
        $mission = $missionId === '' ? null : $missions->getManagement($missionId);
        $missionPeople = $missions->peopleChoices();
        $missionAffairs = $missions->affairChoices();
    } elseif ($view !== 'home') throw new DomainException('Écran non disponible.');
    $choices = $isRh && in_array($view,['new','person'],true) ? $admin->accountChoices() : [];
    $indicators = $isDirection ? $admin->indicators() : [];
    $e = static fn($value) => htmlspecialchars((string)$value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    $csrf = '<input type="hidden" name="csrf" value="'.$e($_SESSION['csrf']).'">';
    require __DIR__.'/../views/application.php';
}

function vigilanceCsvCell(string $value): string
{
    // CSV quoting is not spreadsheet formula escaping. Preserve data as text.
    return preg_match('/^(?:[\x00-\x20]*[=+\-@]|[\t\r\n])/u',$value) ? "'".$value : $value;
}

function vigilancePlanningFilters(array $input): array
{
    $value = static function (string $key) use ($input): ?string {
        $raw = $input[$key] ?? null;
        if (!is_string($raw)) return null;
        $raw = trim($raw);
        return $raw === '' ? null : $raw;
    };
    return ['from'=>$value('from'),'to'=>$value('to'),'person'=>$value('person'),'affair'=>$value('affair'),'site'=>$value('site') ?? ''];
}

function vigilanceAssignmentState(string $state): string
{
    return ['pending'=>'En attente','accepted'=>'Acceptée','refused'=>'Refusée','withdrawn'=>'Retirée'][$state] ?? $state;
}

function vigilanceMissionInput(array $post): array
{
    $input = [];
    foreach (['affair_id','title','site_label','starts_on','ends_on','instructions','risks','epi','internal_note','nextcloud_url'] as $field) {
        $value = $post[$field] ?? '';
        if (!is_string($value)) throw new InvalidArgumentException('Champ de mission invalide.');
        $input[$field] = $value;
    }
    $input['assignments'] = vigilanceMissionAssignments((string)($post['assignments'] ?? ''));
    $input['requirements'] = vigilanceMissionRequirements((string)($post['requirements'] ?? ''));
    $input['resources'] = vigilanceMissionResources((string)($post['resources'] ?? ''));
    return $input;
}

function vigilanceMissionLines(string $raw): array
{
    $lines = preg_split('/\R/u',$raw) ?: [];
    return array_values(array_filter(array_map('trim',$lines),static fn(string $line): bool => $line !== ''));
}

function vigilanceMissionAssignments(string $raw): array
{
    $assignments = [];
    foreach (vigilanceMissionLines($raw) as $line) {
        $parts = array_map('trim',explode(';',$line));
        if (count($parts) !== 6) throw new InvalidArgumentException('Une affectation doit contenir : identifiant équipier ; rôle ; date ; début ; fin ; pause.');
        [$personId,$role,$day,$start,$end,$break] = $parts;
        if ($personId === '' || $day === '' || $start === '' || $end === '') throw new InvalidArgumentException('Affectation incomplète.');
        if (!isset($assignments[$personId])) $assignments[$personId] = ['person_id'=>$personId,'role_label'=>$role === '' ? 'Équipier' : $role,'days'=>[]];
        $assignments[$personId]['days'][] = ['day'=>$day,'starts_at'=>$start,'ends_at'=>$end,'break_minutes'=>$break === '' ? 0 : $break];
    }
    return array_values($assignments);
}

function vigilanceMissionRequirements(string $raw): array
{
    $requirements = [];
    foreach (vigilanceMissionLines($raw) as $line) {
        $parts = array_map('trim',explode(';',$line,4));
        if (count($parts) < 2) throw new InvalidArgumentException('Un prérequis doit contenir : nature ; libellé ; obligatoire ; note.');
        $kind = $parts[0] !== '' ? $parts[0] : 'other';
        if (!in_array($kind,\Vigilance\MissionService::REQUIREMENT_KINDS,true)) throw new InvalidArgumentException('Nature de prérequis invalide.');
        $requirements[] = ['kind'=>$kind,'label'=>$parts[1],'mandatory'=>in_array(strtolower($parts[2] ?? ''),['1','oui','yes','true'],true),'note'=>$parts[3] ?? ''];
    }
    return $requirements;
}

function vigilanceMissionResources(string $raw): array
{
    $resources = [];
    foreach (vigilanceMissionLines($raw) as $line) {
        $parts = array_map('trim',explode(';',$line,3));
        if (count($parts) < 2) throw new InvalidArgumentException('Une ressource doit contenir : titre ; adresse HTTPS ; lecture obligatoire.');
        $resources[] = ['title'=>$parts[0],'url'=>$parts[1],'required_reading'=>in_array(strtolower($parts[2] ?? ''),['1','oui','yes','true'],true)];
    }
    return $resources;
}
