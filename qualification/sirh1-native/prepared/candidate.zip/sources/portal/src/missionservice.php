<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

/**
 * Incrément 1 SIRH.
 *
 * La copie de travail (mission, affectations, jours, prérequis, ressources) est
 * celle du manager. Les équipiers ne lisent que le dernier snapshot publié.
 * Chaque affectation porte une empreinte indépendante : l'ajout d'un collègue
 * ne réinitialise donc pas les acceptations des autres (D-005).
 */
final class MissionService
{
    public const STATUSES = ['draft','published','closed','cancelled'];
    public const REQUIREMENT_KINDS = ['qualification','document','briefing','other'];
    private const TIMEZONE = 'Europe/Paris';

    public function __construct(private readonly Database $db, private readonly Access $access) {}

    public function canReadAll(): bool
    {
        return $this->access->has('direction') || $this->access->has('rh');
    }

    public function canManage(): bool
    {
        return $this->access->has('direction') || $this->access->has('manager');
    }

    public function isWorker(): bool
    {
        return $this->access->has('employee');
    }

    public function currentPerson(): ?array
    {
        $rows = $this->db->rows('SELECT * FROM person WHERE company_id=? AND account_uid=? ORDER BY id LIMIT 2', [$this->access->company,$this->access->uid]);
        if (count($rows) > 1) throw new \DomainException('Plusieurs dossiers sont associés à ce compte. Contactez les RH.');
        return $rows[0] ?? null;
    }

    public function peopleChoices(): array
    {
        if (!$this->canManage() && !$this->access->has('rh')) throw new \DomainException('Liste non autorisée.');
        return $this->db->rows("SELECT id,first_name,last_name,job,status,account_uid FROM person WHERE company_id=? AND status='active' ORDER BY last_name,first_name,id", [$this->access->company]);
    }

    public function affairChoices(): array
    {
        if (!$this->canManage() && !$this->access->has('rh')) throw new \DomainException('Liste non autorisée.');
        return array_values(array_filter((new AffairService($this->db,$this->access))->listing(false),static fn(array $affair): bool => $affair['status']==='active'));
    }

    public function listing(array $filters = []): array
    {
        if (!$this->canManage() && !$this->access->has('rh')) throw new \DomainException('Missions non accessibles.');
        $sql = 'SELECT m.* FROM mission m';
        $where = ['m.company_id=?'];
        $params = [$this->access->company];
        if ($this->access->has('manager') && !$this->access->has('direction') && !$this->access->has('rh')) {
            $person = $this->currentPerson();
            if ($person === null) return [];
            $sql .= ' JOIN affair a ON a.id=m.affair_id AND a.company_id=m.company_id';
            $where[] = 'a.manager_person_id=?';
            $params[] = $person['id'];
        }
        $status = isset($filters['status']) && is_string($filters['status']) ? $filters['status'] : '';
        if ($status !== '' && $status !== 'all') {
            if (!in_array($status,self::STATUSES,true)) throw new \InvalidArgumentException('Statut de mission invalide.');
            $where[] = 'm.status=?';
            $params[] = $status;
        }
        if (!empty($filters['from'])) { $this->dateValue((string)$filters['from']); $where[] = 'm.ends_on>=?'; $params[] = (string)$filters['from']; }
        if (!empty($filters['to'])) { $this->dateValue((string)$filters['to']); $where[] = 'm.starts_on<=?'; $params[] = (string)$filters['to']; }
        if (!empty($filters['affair_id'])) {
            if (!Uuid::valid((string)$filters['affair_id'])) throw new \InvalidArgumentException('Affaire invalide.');
            $where[] = 'm.affair_id=?';
            $params[] = (string)$filters['affair_id'];
        }
        if (!empty($filters['site']) && is_string($filters['site'])) {
            $where[] = 'm.site_label LIKE ? ESCAPE \'!\'';
            $params[] = '%'.str_replace(['!','%','_'],['!!','!%','!_'],trim($filters['site'])).'%';
        }
        $rows = $this->db->rows($sql.' WHERE '.implode(' AND ',$where).' ORDER BY m.starts_on DESC,m.reference',$params);
        return array_map(fn(array $mission): array => $this->decorate($mission),$rows);
    }

    public function workerMissions(): array
    {
        $this->assertWorker();
        $person = $this->currentPerson();
        if ($person === null) return [];
        $rows = $this->db->rows("SELECT DISTINCT m.* FROM mission m JOIN mission_assignment a ON a.mission_id=m.id AND a.company_id=m.company_id WHERE m.company_id=? AND m.current_revision>0 AND m.status IN ('published','closed','cancelled') AND a.person_id=? ORDER BY m.starts_on DESC,m.reference", [$this->access->company,$person['id']]);
        $result = [];
        foreach ($rows as $mission) {
            $latest = $this->latestVersion($mission['id']);
            if ($latest === null) continue;
            $assignment = null;
            foreach ($latest['snapshot']['assignments'] as $candidate) {
                if (($candidate['person_id'] ?? '') === $person['id']) { $assignment = $candidate; break; }
            }
            if ($assignment === null) continue;
            $state = $this->db->rows('SELECT state,accepted_at,refused_at,refusal_reason FROM mission_assignment WHERE company_id=? AND id=?', [$this->access->company,$assignment['id']])[0] ?? null;
            if ($state === null) continue;
            // Project only published business fields; never return the private row.
            $mission = array_merge($latest['snapshot']['mission'],['status'=>$mission['status'],'current_revision'=>(int)$mission['current_revision']]);
            $mission['summary'] = ['total'=>1,'accepted'=>$state['state']==='accepted'?1:0,'pending'=>$state['state']==='pending'?1:0,'refused'=>$state['state']==='refused'?1:0,'withdrawn'=>0,'acceptance'=>$state['state']];
            $mission['own_assignment'] = array_merge($assignment,$state);
            $mission['day_count'] = count($assignment['days']);
            $result[] = $mission;
        }
        usort($result,static fn(array $a,array $b): int => ($b['starts_on'] <=> $a['starts_on']) ?: ($a['reference'] <=> $b['reference']));
        return $result;
    }

    public function getManagement(string $id): array
    {
        $mission = $this->mission($id);
        $this->assertRead($mission);
        $work = $this->workCopy($mission,true);
        $latest = $this->latestVersion($id);
        $snapshot = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
        $mission['assignments'] = $work['assignments'];
        $mission['requirements'] = $work['requirements'];
        $mission['resources'] = $work['resources'];
        $mission['latest_version'] = $latest;
        $mission['summary'] = $this->summary($work['assignments']);
        $mission['conflicts'] = $this->conflictsFrom($work['assignments'],$id);
        $mission['unpublished'] = $latest === null || !hash_equals((string)$latest['content_hash'],(string)$snapshot['content_hash']);
        $mission['editable'] = $this->editable($mission);
        $mission['can_publish'] = in_array($mission['status'],['draft','published'],true)
            && ($mission['status']==='draft' || (int)$mission['current_revision']===0 || $mission['starts_on']>$this->today());
        $mission['orders'] = $this->ordersForMission($id);
        return $mission;
    }

    public function getEmployee(string $id): array
    {
        $this->assertWorker();
        $person = $this->currentPerson();
        if ($person === null) throw new \DomainException('Mission non accessible.');
        $mission = $this->mission($id);
        if (!in_array($mission['status'],['published','closed','cancelled'],true) || (int)$mission['current_revision']<1) throw new \DomainException('Mission non accessible.');
        $latest = $this->latestVersion($id);
        if ($latest === null) throw new \DomainException('Mission non accessible.');
        $snapshotAssignment = null;
        foreach ($latest['snapshot']['assignments'] as $candidate) {
            if (($candidate['person_id'] ?? '') === $person['id']) { $snapshotAssignment = $candidate; break; }
        }
        if ($snapshotAssignment === null) throw new \DomainException('Mission non accessible.');
        $row = $this->db->rows('SELECT * FROM mission_assignment WHERE company_id=? AND id=? AND person_id=?', [$this->access->company,$snapshotAssignment['id'],$person['id']])[0] ?? null;
        if ($row === null || $row['state']==='withdrawn') throw new \DomainException('Mission non accessible.');
        $missionView = $latest['snapshot']['mission'];
        $missionView['id'] = $mission['id'];
        $missionView['status'] = $mission['status'];
        $missionView['cancel_reason'] = $mission['cancel_reason'];
        $missionView['cancelled_at'] = $mission['cancelled_at'];
        $missionView['closed_at'] = $mission['closed_at'];
        $missionView['current_revision'] = (int)$mission['current_revision'];
        $orders = [];
        if ($mission['status'] !== 'cancelled' && $row['state'] === 'accepted' && $this->hasPublishedIdentities($latest['snapshot'])) {
            $orders = $this->db->rows('SELECT * FROM mission_order_document WHERE company_id=? AND assignment_id=? AND content_hash=? AND voided_at IS NULL AND superseded_at IS NULL ORDER BY id DESC LIMIT 1', [$this->access->company,$row['id'],$row['content_hash']]);
        }
        $reads = array_map(static fn(array $read): int => (int)$read['resource_id'],$this->db->rows('SELECT resource_id FROM mission_resource_read WHERE company_id=? AND assignment_id=?', [$this->access->company,$row['id']]));
        return [
            'mission'=>$missionView,
            'assignment'=>array_merge($snapshotAssignment,['state'=>$row['state'],'accepted_at'=>$row['accepted_at'],'refused_at'=>$row['refused_at'],'refusal_reason'=>$row['refusal_reason']]),
            'requirements'=>$latest['snapshot']['requirements'],
            'resources'=>$latest['snapshot']['resources'],
            'reads'=>$reads,
            'version'=>['id'=>$latest['id'],'revision'=>(int)$latest['revision'],'created_at'=>$latest['created_at']],
            'order'=>$orders[0] ?? null,
            'requires_republication'=>!$this->hasPublishedIdentities($latest['snapshot']),
        ];
    }

    public function create(array $input): string
    {
        return $this->db->transaction(function () use ($input): string {
            $this->assertManage();
            $affair = $this->affair((string)($input['affair_id'] ?? ''),true);
            if ($affair['status'] !== 'active') throw new \DomainException('Une mission ne peut être créée que sur une affaire active.');
            $values = $this->normalizeMission($input,null,$affair);
            $id = Uuid::v4();
            $reference = $this->nextReference();
            $now = gmdate('c');
            $this->db->execute('INSERT INTO mission(id,company_id,reference,affair_id,affair_reference,affair_label,client_label,nextcloud_url,title,site_label,starts_on,ends_on,timezone,instructions,risks,epi,internal_note,status,current_revision,revision,created_by_uid,published_at,closed_at,cancelled_at,cancel_reason,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,\'draft\',0,1,?,NULL,NULL,NULL,NULL,?,?)',
                [$id,$this->access->company,$reference,$affair['id'],$affair['reference'],$affair['label'],$affair['client_label'],$values['nextcloud_url'],$values['title'],$values['site_label'],$values['starts_on'],$values['ends_on'],self::TIMEZONE,$values['instructions'],$values['risks'],$values['epi'],$values['internal_note'],$this->access->uid,$now,$now]);
            $mission = $this->mission($id);
            $this->replaceAssignments($mission,$input['assignments'] ?? []);
            $this->replaceRequirements($mission,$input['requirements'] ?? []);
            $this->replaceExternalResources($mission,$input['resources'] ?? []);
            $this->audit($id,'create',1,['reference'=>$reference]);
            return $id;
        });
    }

    /** @return int Nouvelle révision de la copie de travail. */
    public function update(string $id,int $revision,array $input): int
    {
        return $this->db->transaction(function () use ($id,$revision,$input): int {
            $mission = $this->mission($id);
            $this->assertWrite($mission);
            if (!$this->editable($mission)) throw new \DomainException('Cette mission ne peut plus être modifiée. Clôturez-la et créez une nouvelle mission pour la suite.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la avant de modifier.');
            $beforeMission = $mission;
            $affair = $this->affair((string)($input['affair_id'] ?? $mission['affair_id']),true);
            if ($affair['status'] !== 'active' && $affair['id'] !== $mission['affair_id']) throw new \DomainException('Affaire non active.');
            $beforeWork = $this->workCopy($mission,true);
            $before = $this->snapshotFrom($mission,$beforeWork['assignments'],$beforeWork['requirements'],$beforeWork['resources']);
            $values = $this->normalizeMission($input,$mission,$affair);
            $now = gmdate('c');
            $this->db->execute('UPDATE mission SET affair_id=?,affair_reference=?,affair_label=?,client_label=?,nextcloud_url=?,title=?,site_label=?,starts_on=?,ends_on=?,timezone=?,instructions=?,risks=?,epi=?,internal_note=?,updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?',
                [$affair['id'],$values['affair_reference'],$values['affair_label'],$values['client_label'],$values['nextcloud_url'],$values['title'],$values['site_label'],$values['starts_on'],$values['ends_on'],self::TIMEZONE,$values['instructions'],$values['risks'],$values['epi'],$values['internal_note'],$now,$this->access->company,$id,$revision]);
            $mission = $this->mission($id);
            if (array_key_exists('assignments',$input)) $this->replaceAssignments($mission,$input['assignments']);
            if (array_key_exists('requirements',$input)) $this->replaceRequirements($mission,$input['requirements']);
            if (array_key_exists('resources',$input)) $this->replaceExternalResources($mission,$input['resources']);
            $work = $this->workCopy($mission,true);
            $after = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
            $changed = !hash_equals((string)$before['content_hash'],(string)$after['content_hash']);
            $this->audit($id,$changed?'revise':'note',(int)$mission['revision'],['fields'=>$this->changedFields($values,$beforeMission),'internal_only'=>!$changed]);
            return (int)$mission['revision'];
        });
    }

    /** @return array{id:string,revision:int} */
    public function publish(string $id,int $revision): array
    {
        return $this->db->transaction(function () use ($id,$revision): array {
            $mission = $this->mission($id);
            $this->assertWrite($mission);
            if (!in_array($mission['status'],['draft','published'],true)) throw new \DomainException('Cette mission ne peut plus être publiée.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la avant de publier.');
            if ((int)$mission['current_revision']>0 && $mission['starts_on'] <= $this->today()) throw new \DomainException('La mission a commencé : créez une nouvelle mission pour la suite.');
            $work = $this->workCopy($mission,true);
            $this->assertPublishable($mission,$work);
            $snapshot = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
            $latest = $this->latestVersion($id);
            $previous = [];
            if ($latest !== null) foreach ($latest['snapshot']['assignments'] as $assignment) $previous[$assignment['person_id']] = $assignment;
            $current = [];
            foreach ($snapshot['assignments'] as $assignment) $current[$assignment['person_id']] = $assignment;
            $added = false; $removed = false; $changed = false;
            foreach ($current as $personId => $assignment) {
                if (!isset($previous[$personId])) $added = true;
                elseif (!hash_equals((string)$previous[$personId]['content_hash'],(string)$assignment['content_hash'])) $changed = true;
            }
            foreach ($previous as $personId => $assignment) if (!isset($current[$personId])) $removed = true;
            $reason = $latest === null ? 'publication' : ($changed ? 'major_change' : (($added || $removed) ? 'membership_change' : 'correction'));
            $newRevision = (int)($latest['revision'] ?? 0) + 1;
            $versionId = Uuid::v4();
            $now = gmdate('c');
            $this->db->execute('INSERT INTO mission_version(id,company_id,mission_id,revision,content_hash,snapshot_json,reason,created_by_uid,created_at) VALUES (?,?,?,?,?,?,?,?,?)',
                [$versionId,$this->access->company,$id,$newRevision,$snapshot['content_hash'],json_encode($snapshot,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$reason,$this->access->uid,$now]);
            $notifyPublished = []; $notifyChanged = []; $notifyRemoved = [];
            foreach ($work['assignments'] as $row) {
                if ($row['state']==='withdrawn') {
                    $this->db->execute('UPDATE mission_assignment SET state=\'withdrawn\',content_hash=\'\',accepted_version_id=NULL,accepted_at=NULL,refused_at=NULL,refusal_reason=NULL,updated_at=? WHERE company_id=? AND id=?', [$now,$this->access->company,$row['id']]);
                    $this->db->execute('UPDATE mission_order_document SET superseded_at=? WHERE company_id=? AND assignment_id=? AND superseded_at IS NULL', [$now,$this->access->company,$row['id']]);
                    if (isset($previous[$row['person_id']])) $notifyRemoved[] = $row;
                    continue;
                }
                $assignment = $current[$row['person_id']] ?? null;
                if ($assignment === null) continue;
                $newHash = (string)$assignment['content_hash'];
                $oldHash = (string)$row['content_hash'];
                $state = (string)$row['state'];
                $newMember = !isset($previous[$row['person_id']]);
                if ($newMember || $oldHash === '' || !hash_equals($oldHash,$newHash)) {
                    $state = 'pending';
                    $this->db->execute('UPDATE mission_assignment SET state=\'pending\',content_hash=?,accepted_version_id=NULL,accepted_at=NULL,refused_at=NULL,refusal_reason=NULL,updated_at=? WHERE company_id=? AND id=?',
                        [$newHash,$now,$this->access->company,$row['id']]);
                    $this->db->execute('UPDATE mission_order_document SET superseded_at=? WHERE company_id=? AND assignment_id=? AND superseded_at IS NULL', [$now,$this->access->company,$row['id']]);
                    if ($newMember) $notifyPublished[] = $row;
                    else $notifyChanged[] = $row;
                } else {
                    $this->db->execute('UPDATE mission_assignment SET content_hash=?,state=?,updated_at=? WHERE company_id=? AND id=?', [$newHash,$state,$now,$this->access->company,$row['id']]);
                }
            }
            $this->db->execute('UPDATE mission SET status=\'published\',current_revision=?,published_at=COALESCE(published_at,?),updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?',
                [$newRevision,$now,$now,$this->access->company,$id,$revision]);
            $this->audit($id,'publish',$newRevision,['version'=>$newRevision,'reason'=>$reason]);
            $context = new JourneyContext($this->db,$this->access);
            foreach ($notifyPublished as $row) {
                if (($row['account_uid'] ?? '')!=='') $context->notify('Nouvelle mission','Une mission vous est proposée. Consultez-la dans VIGILance et répondez personnellement.',[],(string)$row['account_uid'],'mission.published');
            }
            foreach ($notifyChanged as $row) {
                if (($row['account_uid'] ?? '')!=='') $context->notify('Mission modifiée','Une mission à laquelle vous êtes affecté a changé. Vérifiez-la dans VIGILance et répondez de nouveau si nécessaire.',[],(string)$row['account_uid'],'mission.changed');
            }
            foreach ($notifyRemoved as $row) {
                if (($row['account_uid'] ?? '')!=='') $context->notify('Mission retirée','Vous n’êtes plus affecté à cette mission. Consultez votre planning dans VIGILance.',[],(string)$row['account_uid'],'mission.cancelled');
            }
            return ['id'=>$versionId,'revision'=>$newRevision];
        });
    }

    public function accept(string $assignmentId,bool $acknowledged,string $expectedVersion='',string $expectedHash=''): int
    {
        return $this->db->transaction(function () use ($assignmentId,$acknowledged,$expectedVersion,$expectedHash): int {
            $this->assertWorker();
            if (!$acknowledged) throw new \InvalidArgumentException('Confirmez avoir lu et compris l’ordre de mission.');
            $assignment = $this->ownAssignment($assignmentId);
            $mission = $this->mission((string)$assignment['mission_id']);
            if ($mission['status'] !== 'published') throw new \DomainException('Cette mission n’est plus ouverte à l’acceptation.');
            if ($assignment['state'] !== 'pending') throw new \DomainException('Cette affectation a déjà reçu une réponse.');
            $latest = $this->latestVersion($mission['id']);
            if ($latest === null) throw new \DomainException('Mission non accessible.');
            $this->assertResponseVersion($latest,$expectedVersion,$expectedHash,$assignment);
            if (!$this->hasPublishedIdentities($latest['snapshot'])) throw new \DomainException('Cette ancienne version ne fige pas le responsable et l’entreprise. Demandez une nouvelle publication avant de l’accepter.');
            $snapshotAssignment = null;
            foreach ($latest['snapshot']['assignments'] as $candidate) if (($candidate['id'] ?? '') === $assignment['id']) { $snapshotAssignment = $candidate; break; }
            if ($snapshotAssignment === null || !hash_equals((string)$snapshotAssignment['content_hash'],(string)$assignment['content_hash'])) throw new \DomainException('La mission a changé. Rechargez-la.');
            $existing = $this->db->rows('SELECT id FROM mission_acceptance WHERE company_id=? AND assignment_id=? AND version_id=?', [$this->access->company,$assignment['id'],$latest['id']]);
            if ($existing) throw new \DomainException('Une réponse a déjà été enregistrée pour cette version.');
            $now = gmdate('c');
            $this->db->execute('INSERT INTO mission_acceptance(company_id,assignment_id,version_id,content_hash,decision,reason,decided_at,actor_uid) VALUES (?,?,?,?,?,NULL,?,?)',
                [$this->access->company,$assignment['id'],$latest['id'],$assignment['content_hash'],'accepted',$now,$this->access->uid]);
            $this->db->execute('UPDATE mission_assignment SET state=\'accepted\',accepted_version_id=?,accepted_at=?,refused_at=NULL,refusal_reason=NULL,updated_at=? WHERE company_id=? AND id=?',
                [$latest['id'],$now,$now,$this->access->company,$assignment['id']]);
            $this->audit($mission['id'],'accept',(int)$latest['revision'],['assignment'=>$assignment['id']]);
            $orderId = $this->generateOrder($mission,$latest,$snapshotAssignment,$now);
            $this->notifyAffairManager($mission,'Mission acceptée','Une mission a été acceptée par un équipier. Consultez le suivi dans VIGILance.','mission.accepted');
            return $orderId;
        });
    }

    public function refuse(string $assignmentId,string $reason,string $expectedVersion='',string $expectedHash=''): void
    {
        $this->db->transaction(function () use ($assignmentId,$reason,$expectedVersion,$expectedHash): void {
            $this->assertWorker();
            $reason = $this->multiline($reason,1000,true);
            $assignment = $this->ownAssignment($assignmentId);
            $mission = $this->mission((string)$assignment['mission_id']);
            if ($mission['status'] !== 'published') throw new \DomainException('Cette mission n’est plus ouverte à une réponse.');
            if ($assignment['state'] !== 'pending') throw new \DomainException('Cette affectation a déjà reçu une réponse.');
            $latest = $this->latestVersion($mission['id']);
            if ($latest === null) throw new \DomainException('Mission non accessible.');
            $this->assertResponseVersion($latest,$expectedVersion,$expectedHash,$assignment);
            $snapshotAssignment = null;
            foreach ($latest['snapshot']['assignments'] as $candidate) if (($candidate['id'] ?? '') === $assignment['id']) { $snapshotAssignment = $candidate; break; }
            if ($snapshotAssignment === null || !hash_equals((string)$snapshotAssignment['content_hash'],(string)$assignment['content_hash'])) throw new \DomainException('La mission a changé. Rechargez-la.');
            $existing = $this->db->rows('SELECT id FROM mission_acceptance WHERE company_id=? AND assignment_id=? AND version_id=?', [$this->access->company,$assignment['id'],$latest['id']]);
            if ($existing) throw new \DomainException('Une réponse a déjà été enregistrée pour cette version.');
            $now = gmdate('c');
            $this->db->execute('INSERT INTO mission_acceptance(company_id,assignment_id,version_id,content_hash,decision,reason,decided_at,actor_uid) VALUES (?,?,?,?,?,?,?,?)',
                [$this->access->company,$assignment['id'],$latest['id'],$assignment['content_hash'],'refused',$reason,$now,$this->access->uid]);
            $this->db->execute('UPDATE mission_assignment SET state=\'refused\',refused_at=?,refusal_reason=?,updated_at=? WHERE company_id=? AND id=?',
                [$now,$reason,$now,$this->access->company,$assignment['id']]);
            $this->audit($mission['id'],'refuse',(int)$latest['revision'],['assignment'=>$assignment['id']]);
            $context = new JourneyContext($this->db,$this->access);
            $managerUid = $this->affairManagerUid($mission);
            if ($managerUid !== null) $context->notify('Mission refusée','Un équipier a refusé sa mission. Consultez le suivi dans VIGILance.',[],$managerUid,'mission.refused');
            $context->notify('Mission refusée','Un équipier a refusé sa mission. Consultez le suivi dans VIGILance.',['direction'],null,'mission.refused');
        });
    }

    public function cancel(string $id,int $revision,string $reason): void
    {
        $this->db->transaction(function () use ($id,$revision,$reason): void {
            $mission = $this->mission($id);
            $this->assertWrite($mission);
            if (!in_array($mission['status'],['draft','published'],true)) throw new \DomainException('Cette mission ne peut plus être annulée.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la.');
            $reason = $this->multiline($reason,1000,true);
            $now = gmdate('c');
            $wasPublished = (int)$mission['current_revision']>0;
            $work = $this->workCopy($mission,true);
            $this->db->execute('UPDATE mission SET status=\'cancelled\',cancelled_at=?,cancel_reason=?,updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?',
                [$now,$reason,$now,$this->access->company,$id,$revision]);
            $this->db->execute('UPDATE mission_order_document SET voided_at=? WHERE company_id=? AND mission_id=? AND voided_at IS NULL', [$now,$this->access->company,$id]);
            $this->audit($id,'cancel',(int)$mission['current_revision'],['reason_present'=>true]);
            if (!$wasPublished) return;
            $context = new JourneyContext($this->db,$this->access);
            $publishedMembers = array_column($this->latestVersion($id)['snapshot']['assignments'] ?? [],'id');
            foreach ($work['assignments'] as $assignment) {
                if (!in_array($assignment['id'],$publishedMembers,true) || ($assignment['account_uid'] ?? '')==='') continue;
                $context->notify('Mission annulée','Une mission à laquelle vous êtes affecté a été annulée. Consultez VIGILance pour le détail.',[],(string)$assignment['account_uid'],'mission.cancelled');
            }
            $managerUid = $this->affairManagerUid($mission);
            if ($managerUid !== null) $context->notify('Mission annulée','Une mission a été annulée. Consultez le suivi dans VIGILance.',[],$managerUid);
            $context->notify('Mission annulée','Une mission a été annulée. Consultez le suivi dans VIGILance.',['direction']);
        });
    }

    public function close(string $id,int $revision,string $note=''): void
    {
        $this->db->transaction(function () use ($id,$revision,$note): void {
            $mission = $this->mission($id);
            $this->assertWrite($mission);
            if ($mission['status'] !== 'published') throw new \DomainException('Seule une mission publiée peut être clôturée.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la.');
            $note = $this->multiline($note,1000,false);
            $now = gmdate('c');
            $this->db->execute('UPDATE mission SET status=\'closed\',closed_at=?,updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?',
                [$now,$now,$this->access->company,$id,$revision]);
            $this->audit($id,'close',(int)$mission['current_revision'],['note_present'=>$note!=='']);
        });
    }

    public function planning(?string $from=null,?string $to=null,?string $personId=null,?string $affairId=null,string $site=''): array
    {
        $employee = $this->access->has('employee');
        $manage = $this->canManage();
        $rh = $this->access->has('rh');
        if (!$employee && !$manage && !$rh) throw new \DomainException('Planning non accessible.');
        $from ??= (new \DateTimeImmutable('-7 days',new \DateTimeZone(self::TIMEZONE)))->format('Y-m-d');
        $to ??= (new \DateTimeImmutable('+30 days',new \DateTimeZone(self::TIMEZONE)))->format('Y-m-d');
        $this->dateValue($from); $this->dateValue($to);
        if ($to < $from) throw new \InvalidArgumentException('Période de planning invalide.');
        if ((new \DateTimeImmutable($from))->diff(new \DateTimeImmutable($to))->days > 366) throw new \InvalidArgumentException('Période de planning trop longue.');
        $selfOnly = $employee && !$manage && !$rh;
        if ($selfOnly) {
            $person = $this->currentPerson();
            if ($person === null) return [];
            $personId = $person['id'];
            $includeDrafts = false;
        } else {
            $includeDrafts = $manage;
        }
        if ($personId !== null && $personId !== '' && !Uuid::valid($personId)) throw new \InvalidArgumentException('Équipier invalide.');
        if ($affairId !== null && $affairId !== '' && !Uuid::valid($affairId)) throw new \InvalidArgumentException('Affaire invalide.');
        $sql = 'SELECT m.* FROM mission m';
        $where = ['m.company_id=?'];
        $params = [$this->access->company];
        if ($selfOnly) {
            $sql .= ' JOIN mission_assignment a ON a.mission_id=m.id AND a.company_id=m.company_id';
            $where[] = 'a.person_id=?';
            $params[] = (string)$personId;
            $where[] = "m.status='published' AND m.current_revision>0";
        } else {
            if ($this->access->has('manager') && !$this->access->has('direction') && !$this->access->has('rh')) {
                $person = $this->currentPerson();
                if ($person === null) return [];
                $sql .= ' JOIN affair af ON af.id=m.affair_id AND af.company_id=m.company_id';
                $where[] = 'af.manager_person_id=?';
                $params[] = $person['id'];
            }
            $where[] = $includeDrafts ? "m.status IN ('draft','published')" : "m.status='published'";
        }
        // Published readers must not be filtered out by private period/affair edits.
        if ($includeDrafts) {
            $where[] = "(m.status='published' OR (m.ends_on>=? AND m.starts_on<=?))";
            $params[] = $from; $params[] = $to;
            if ($affairId !== null && $affairId !== '') { $where[] = "(m.status='published' OR m.affair_id=?)"; $params[] = $affairId; }
        }
        $rows = $this->db->rows($sql.' WHERE '.implode(' AND ',$where).' ORDER BY m.starts_on,m.reference',$params);
        $result = [];
        foreach ($rows as $mission) {
            $latest = $this->latestVersion($mission['id']);
            $work = null;
            if ((int)$mission['current_revision']>0 && $latest !== null) {
                $assignmentSource = $latest['snapshot']['assignments'];
                $missionSource = $latest['snapshot']['mission'];
                $unpublished = false;
                if ($manage) {
                    $work = $this->workCopy($mission,true);
                    $current = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
                    $unpublished = !hash_equals((string)$latest['content_hash'],(string)$current['content_hash']);
                }
            } else {
                if (!$includeDrafts) continue;
                $work = $this->workCopy($mission,true);
                $assignmentSource = $work['assignments'];
                $missionSource = $mission;
                $unpublished = true;
            }
            $stateByAssignment = [];
            if ($affairId !== null && $affairId !== '' && $missionSource['affair_id']!==$affairId) continue;
            foreach ($this->db->rows('SELECT id,state FROM mission_assignment WHERE company_id=? AND mission_id=?', [$this->access->company,$mission['id']]) as $stateRow) $stateByAssignment[$stateRow['id']] = $stateRow['state'];
            foreach ($assignmentSource as $assignment) {
                if (($stateByAssignment[$assignment['id']] ?? '')==='withdrawn') continue;
                if ($selfOnly && $assignment['person_id'] !== $personId) continue;
                if ($personId !== null && $personId !== '' && !$selfOnly && $assignment['person_id'] !== $personId) continue;
                foreach ($assignment['days'] as $day) {
                    if ($day['day'] < $from || $day['day'] > $to) continue;
                    if ($site !== '' && mb_stripos((string)$missionSource['site_label'],$site)===false) continue;
                    $result[] = [
                        'day'=>$day['day'],
                        'starts_at'=>$day['starts_at'],
                        'ends_at'=>$day['ends_at'],
                        'break_minutes'=>(int)$day['break_minutes'],
                        'person_id'=>$assignment['person_id'],
                        'person_name'=>trim(($assignment['first_name'] ?? '').' '.($assignment['last_name'] ?? '')),
                        'assignment_id'=>$assignment['id'],
                        'mission_id'=>$mission['id'],
                        'mission_reference'=>$missionSource['reference'],
                        'mission_title'=>$missionSource['title'],
                        'mission_status'=>$mission['status'],
                        'site_label'=>$missionSource['site_label'],
                        'affair_reference'=>$missionSource['affair_reference'],
                        'affair_label'=>$missionSource['affair_label'],
                        'state'=>$stateByAssignment[$assignment['id']] ?? ($assignment['state'] ?? 'pending'),
                        'unpublished'=>$unpublished,
                    ];
                }
            }
        }
        usort($result,static fn(array $a,array $b): int => [$a['day'],$a['starts_at'],$a['person_name'],$a['mission_reference']] <=> [$b['day'],$b['starts_at'],$b['person_name'],$b['mission_reference']]);
        return $result;
    }

    public function addInternalResource(string $missionId,int $revision,string $title,bool $requiredReading,string $temporaryPath,string $originalName=''): int
    {
        return $this->db->transaction(function () use ($missionId,$revision,$title,$requiredReading,$temporaryPath,$originalName): int {
            $mission = $this->mission($missionId);
            $this->assertWrite($mission);
            if (!$this->editable($mission)) throw new \DomainException('Cette mission ne peut plus être modifiée.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la avant d’ajouter un document.');
            $title = $this->line($title,180,true);
            if (!is_file($temporaryPath) || !is_readable($temporaryPath)) throw new \InvalidArgumentException('Fichier invalide.');
            $bytes = filesize($temporaryPath);
            if ($bytes === false || $bytes < 1 || $bytes > 10485760) throw new \InvalidArgumentException('Le document doit faire entre 1 octet et 10 Mo.');
            $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($temporaryPath);
            $extensions = ['application/pdf'=>'pdf','image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp','text/plain'=>'txt'];
            if (!is_string($mime) || !isset($extensions[$mime])) throw new \InvalidArgumentException('Seuls les PDF, PNG, JPEG, WebP et textes simples sont acceptés.');
            $extension = $extensions[$mime];
            $storage = 'resources/'.$this->access->company.'/'.bin2hex(random_bytes(16)).'.'.$extension;
            $destination = $this->privatePath($storage,false);
            $this->ensureDirectory(dirname($destination));
            $moved = is_uploaded_file($temporaryPath) ? move_uploaded_file($temporaryPath,$destination) : rename($temporaryPath,$destination);
            if (!$moved || !is_file($destination)) throw new \RuntimeException('Enregistrement du document impossible.');
            chmod($destination,0600);
            $sha = hash_file('sha256',$destination);
            $position = 1000 + (int)($this->db->rows("SELECT COUNT(*) AS count FROM mission_resource WHERE company_id=? AND mission_id=? AND kind='internal_file' AND superseded_at IS NULL", [$this->access->company,$missionId])[0]['count'] ?? 0);
            $this->db->execute('INSERT INTO mission_resource(company_id,mission_id,kind,title,url,storage_name,mime,bytes,sha256,required_reading,position,created_at,superseded_at) VALUES (?,?,?,?,NULL,?,?,?,?,?,?,?,NULL)',
                [$this->access->company,$missionId,'internal_file',$title,$storage,$mime,$bytes,$sha,$requiredReading?1:0,$position,gmdate('c')]);
            $id = (int)$this->db->pdo->lastInsertId();
            $this->db->execute('UPDATE mission SET updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?', [gmdate('c'),$this->access->company,$missionId,$revision]);
            $this->audit($missionId,'resource_upload',(int)$mission['revision']+1,['resource'=>$id]);
            return $id;
        });
    }

    public function removeResource(string $missionId,int $revision,int $resourceId): void
    {
        $this->db->transaction(function () use ($missionId,$revision,$resourceId): void {
            $mission = $this->mission($missionId);
            $this->assertWrite($mission);
            if (!$this->editable($mission)) throw new \DomainException('Cette mission ne peut plus être modifiée.');
            if ($revision < 1 || (int)$mission['revision'] !== $revision) throw new \DomainException('La mission a changé. Rechargez-la.');
            $resource = $this->db->rows('SELECT * FROM mission_resource WHERE company_id=? AND mission_id=? AND id=? AND superseded_at IS NULL', [$this->access->company,$missionId,$resourceId]);
            if (!$resource) throw new \DomainException('Ressource non accessible.');
            $this->db->execute('UPDATE mission_resource SET superseded_at=? WHERE company_id=? AND id=?', [gmdate('c'),$this->access->company,$resourceId]);
            $this->db->execute('UPDATE mission SET updated_at=?,revision=revision+1 WHERE company_id=? AND id=? AND revision=?', [gmdate('c'),$this->access->company,$missionId,$revision]);
            $this->audit($missionId,'resource_remove',(int)$mission['revision']+1,['resource'=>$resourceId]);
        });
    }

    public function markResourceRead(string $assignmentId,int $resourceId): void
    {
        $this->db->transaction(function () use ($assignmentId,$resourceId): void {
            $this->assertWorker();
            $assignment = $this->ownAssignment($assignmentId);
            $mission = $this->mission((string)$assignment['mission_id']);
            if ($mission['status'] !== 'published') throw new \DomainException('Cette mission n’est plus ouverte.');
            $latest = $this->latestVersion($mission['id']);
            if ($latest === null) throw new \DomainException('Mission non accessible.');
            $inSnapshot = false;
            foreach ($latest['snapshot']['assignments'] as $candidate) if (($candidate['id'] ?? '')===$assignment['id']) $inSnapshot = true;
            if (!$inSnapshot) throw new \DomainException('Mission non accessible.');
            $resource = null;
            foreach ($latest['snapshot']['resources'] as $candidate) if ((int)($candidate['id'] ?? 0)===$resourceId) { $resource = $candidate; break; }
            if ($resource === null || ($resource['kind'] ?? '')!=='internal_file') throw new \DomainException('Document non accessible.');
            $this->db->execute('INSERT OR IGNORE INTO mission_resource_read(company_id,assignment_id,resource_id,read_at) VALUES (?,?,?,?)', [$this->access->company,$assignment['id'],$resourceId,gmdate('c')]);
            $this->audit($mission['id'],'read_resource',(int)$latest['revision'],['assignment'=>$assignment['id'],'resource'=>$resourceId]);
        });
    }

    public function orderForAssignment(string $assignmentId): array
    {
        $assignment = $this->assignment($assignmentId);
        $mission = $this->mission((string)$assignment['mission_id']);
        if ($this->access->has('employee') && !$this->canManage() && !$this->access->has('rh') && !$this->access->has('direction')) {
            $person = $this->currentPerson();
            if ($person === null || $assignment['person_id'] !== $person['id']) throw new \DomainException('Ordre de mission non accessible.');
            if (!in_array($mission['status'],['published','closed','cancelled'],true)) throw new \DomainException('Ordre de mission non accessible.');
        } else {
            $this->assertRead($mission);
        }
        $rows = $this->db->rows('SELECT id FROM mission_order_document WHERE company_id=? AND assignment_id=? ORDER BY id DESC LIMIT 1', [$this->access->company,$assignmentId]);
        if (!$rows) throw new \DomainException('Aucun ordre de mission disponible.');
        return $this->orderDocument((int)$rows[0]['id']);
    }

    public function orderDocument(int $documentId,bool $historical=false): array
    {
        // Linearize authorization, published state and invalidation checks with
        // writers. A stream already authorized cannot be recalled retroactively.
        return $this->db->transaction(fn(): array => $this->checkedOrderDocument($documentId,$historical));
    }

    private function checkedOrderDocument(int $documentId,bool $historical): array
    {
        $rows = $this->db->rows('SELECT d.*,a.person_id,m.status AS mission_status,m.reference AS mission_reference FROM mission_order_document d JOIN mission_assignment a ON a.id=d.assignment_id AND a.company_id=d.company_id JOIN mission m ON m.id=d.mission_id AND m.company_id=d.company_id WHERE d.company_id=? AND d.id=?', [$this->access->company,$documentId]);
        if (!$rows) throw new \DomainException('Ordre de mission non accessible.');
        $document = $rows[0];
        $mission = $this->mission((string)$document['mission_id']);
        if ($historical) $this->assertManageRead($mission);
        if ($this->access->has('employee') && !$this->canManage() && !$this->access->has('rh') && !$this->access->has('direction')) {
            $person = $this->currentPerson();
            if ($person === null || $document['person_id'] !== $person['id']) throw new \DomainException('Ordre de mission non accessible.');
            if (!in_array($mission['status'],['published','closed'],true)) throw new \DomainException('Ordre de mission non accessible.');
            if ($document['voided_at'] !== null || $document['superseded_at'] !== null) throw new \DomainException('Cet ordre de mission n’est plus valide.');
        } else {
            $this->assertRead($mission);
        }
        if (!$historical) {
            $assignment = $this->assignment((string)$document['assignment_id']);
            $latest = $this->latestVersion((string)$document['mission_id']);
            $publishedHash = null;
            foreach ($latest['snapshot']['assignments'] ?? [] as $candidate) if ($candidate['id']===$assignment['id']) $publishedHash=(string)$candidate['content_hash'];
            if (!$this->hasPublishedIdentities($latest['snapshot'] ?? []) || !in_array($mission['status'],['published','closed'],true) || $assignment['state']!=='accepted'
                || $document['voided_at']!==null || $document['superseded_at']!==null || $publishedHash===null
                || !hash_equals((string)$document['content_hash'],(string)$assignment['content_hash'])
                || !hash_equals((string)$document['content_hash'],$publishedHash)) throw new \DomainException('Cet ordre de mission n’est plus valide.');
        }
        $path = $this->privatePath((string)$document['storage_name']);
        if (!is_file($path) || !hash_equals((string)$document['sha256'],(string)hash_file('sha256',$path))) throw new \DomainException('Ordre de mission indisponible.');
        return ['document'=>$document,'path'=>$path,'filename'=>'ordre-mission-'.$document['mission_reference'].'.pdf','mime'=>'application/pdf'];
    }

    public function draftPdf(string $missionId,?string $assignmentId=null): array
    {
        $mission = $this->mission($missionId);
        $this->assertWrite($mission);
        $work = $this->workCopy($mission,true);
        $snapshot = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
        $assignment = null;
        foreach ($snapshot['assignments'] as $candidate) if ($assignmentId===null || $candidate['id']===$assignmentId) { $assignment = $candidate; break; }
        if ($assignment === null) throw new \DomainException('Aucun équipier à prévisualiser.');
        $latest = $this->latestVersion($missionId);
        $version = ['revision'=>(int)($latest['revision'] ?? 0),'created_at'=>$latest['created_at'] ?? gmdate('c')];
        $view = $this->pdfView($mission,$snapshot,$assignment,$version,null);
        $pdf = (new MissionPdf())->render($view,$assignment,true);
        return ['body'=>$pdf,'filename'=>'brouillon-'.$mission['reference'].'.pdf','mime'=>'application/pdf'];
    }

    public function resourceForDownload(int $resourceId): array
    {
        $rows = $this->db->rows('SELECT * FROM mission_resource WHERE company_id=? AND id=?', [$this->access->company,$resourceId]);
        if (!$rows) throw new \DomainException('Document non accessible.');
        $resource = $rows[0];
        if ($resource['kind'] !== 'internal_file') throw new \DomainException('Document non accessible.');
        $mission = $this->mission((string)$resource['mission_id']);
        if ($this->access->has('employee') && !$this->canManage() && !$this->access->has('rh') && !$this->access->has('direction')) {
            $person = $this->currentPerson();
            if ($person === null || !in_array($mission['status'],['published','closed','cancelled'],true)) throw new \DomainException('Document non accessible.');
            $latest = $this->latestVersion($mission['id']);
            if ($latest === null) throw new \DomainException('Document non accessible.');
            $inSnapshot = false;
            foreach ($latest['snapshot']['resources'] as $candidate) if ((int)($candidate['id'] ?? 0)===$resourceId) { $inSnapshot = true; break; }
            $assigned = false;
            foreach ($latest['snapshot']['assignments'] as $candidate) if (($candidate['person_id'] ?? '')===$person['id']) { $assigned = true; break; }
            if (!$inSnapshot || !$assigned) throw new \DomainException('Document non accessible.');
        } else {
            $this->assertRead($mission);
        }
        $path = $this->privatePath((string)$resource['storage_name']);
        if (!is_file($path) || !hash_equals((string)$resource['sha256'],(string)hash_file('sha256',$path))) throw new \DomainException('Document indisponible.');
        $extension = pathinfo($path,PATHINFO_EXTENSION);
        $mime = (string)$resource['mime'];
        return ['path'=>$path,'filename'=>'document-'.$resource['id'].'.'.$extension,'mime'=>$mime,'title'=>$resource['title']];
    }

    /** @return array<int,array> */
    public function ordersForMission(string $missionId): array
    {
        $mission = $this->mission($missionId);
        $this->assertRead($mission);
        return $this->db->rows('SELECT d.*,a.person_id,p.first_name,p.last_name FROM mission_order_document d JOIN mission_assignment a ON a.id=d.assignment_id AND a.company_id=d.company_id JOIN person p ON p.id=a.person_id AND p.company_id=a.company_id WHERE d.company_id=? AND d.mission_id=? ORDER BY d.id DESC', [$this->access->company,$missionId]);
    }

    private function mission(string $id): array
    {
        if (!Uuid::valid($id)) throw new \InvalidArgumentException('Mission invalide.');
        $rows = $this->db->rows('SELECT * FROM mission WHERE company_id=? AND id=?', [$this->access->company,$id]);
        if (!$rows) throw new \DomainException('Mission non accessible.');
        return $rows[0];
    }

    private function assignment(string $id): array
    {
        if (!Uuid::valid($id)) throw new \InvalidArgumentException('Affectation invalide.');
        $rows = $this->db->rows('SELECT * FROM mission_assignment WHERE company_id=? AND id=?', [$this->access->company,$id]);
        if (!$rows) throw new \DomainException('Affectation non accessible.');
        return $rows[0];
    }

    private function ownAssignment(string $id): array
    {
        $assignment = $this->assignment($id);
        $person = $this->currentPerson();
        if ($person === null || $assignment['person_id'] !== $person['id']) throw new \DomainException('Affectation non accessible.');
        return $assignment;
    }

    private function assertResponseVersion(array $latest,string $expectedVersion,string $expectedHash,array $assignment): void
    {
        // Executed under BEGIN IMMEDIATE, before any decision, audit, mail or PDF.
        if ($expectedVersion==='' || $expectedHash==='' || !hash_equals((string)$latest['id'],$expectedVersion)
            || !hash_equals((string)$assignment['content_hash'],$expectedHash)) {
            throw new \DomainException('La mission a changé ou le formulaire est périmé. Rechargez-la et relisez-la avant de répondre.');
        }
    }

    private function hasPublishedIdentities(array $snapshot): bool
    {
        return is_string($snapshot['mission']['manager_name'] ?? null) && trim($snapshot['mission']['manager_name'])!==''
            && is_string($snapshot['mission']['company_name'] ?? null) && trim($snapshot['mission']['company_name'])!=='';
    }

    private function affair(string $id,bool $write): array
    {
        if (!Uuid::valid($id)) throw new \InvalidArgumentException('Affaire invalide.');
        $rows = $this->db->rows('SELECT * FROM affair WHERE company_id=? AND id=?', [$this->access->company,$id]);
        if (!$rows) throw new \DomainException('Affaire non accessible.');
        $affair = $rows[0];
        if ($this->access->has('direction')) return $affair;
        if (!$this->access->has('manager')) throw new \DomainException('Affaire non accessible.');
        $person = $this->currentPerson();
        if ($person === null || $affair['manager_person_id'] !== $person['id']) throw new \DomainException('Affaire non accessible.');
        if ($write && $affair['status'] !== 'active') throw new \DomainException('Affaire non active.');
        return $affair;
    }

    private function assertManage(): void
    {
        if (!$this->canManage()) throw new \DomainException('Gestion des missions non autorisée.');
    }

    private function assertWorker(): void
    {
        if (!$this->isWorker()) throw new \DomainException('Action réservée à l’équipier affecté.');
    }

    private function assertManageRead(array $mission): void
    {
        if ($this->access->has('direction') || $this->access->has('rh')) return;
        if (!$this->access->has('manager')) throw new \DomainException('Mission non accessible.');
        $person = $this->currentPerson();
        $affair = $this->db->rows('SELECT manager_person_id FROM affair WHERE company_id=? AND id=?', [$this->access->company,$mission['affair_id']])[0] ?? null;
        if ($person === null || $affair === null || $affair['manager_person_id'] !== $person['id']) throw new \DomainException('Mission non accessible.');
    }

    private function assertRead(array $mission): void
    {
        if ($this->access->has('direction') || $this->access->has('rh')) return;
        if ($this->access->has('manager') && !$this->access->has('employee')) { $this->assertManageRead($mission); return; }
        if ($this->access->has('manager') && $this->access->has('employee')) {
            // Le profil actif est unique : un manager ne cumule pas les droits équipier.
            $this->assertManageRead($mission);
            return;
        }
        if (!$this->access->has('employee')) throw new \DomainException('Mission non accessible.');
        if (!in_array($mission['status'],['published','closed','cancelled'],true) || (int)$mission['current_revision']<1) throw new \DomainException('Mission non accessible.');
        $person = $this->currentPerson();
        if ($person === null) throw new \DomainException('Mission non accessible.');
        $latest = $this->latestVersion($mission['id']);
        if ($latest === null) throw new \DomainException('Mission non accessible.');
        foreach ($latest['snapshot']['assignments'] as $assignment) if (($assignment['person_id'] ?? '')===$person['id']) return;
        throw new \DomainException('Mission non accessible.');
    }

    private function assertWrite(array $mission): void
    {
        if ($this->access->has('direction')) return;
        if (!$this->access->has('manager')) throw new \DomainException('Modification de mission non autorisée.');
        $person = $this->currentPerson();
        $affair = $this->db->rows('SELECT manager_person_id,status FROM affair WHERE company_id=? AND id=?', [$this->access->company,$mission['affair_id']])[0] ?? null;
        if ($person === null || $affair === null || $affair['manager_person_id'] !== $person['id']) throw new \DomainException('Mission non accessible.');
        if ($affair['status'] !== 'active') throw new \DomainException('Affaire non active.');
    }

    private function editable(array $mission): bool
    {
        if ($mission['status'] === 'draft') return true;
        return $mission['status'] === 'published' && $mission['starts_on'] > $this->today();
    }

    private function today(): string
    {
        return (new \DateTimeImmutable('today',new \DateTimeZone(self::TIMEZONE)))->format('Y-m-d');
    }

    private function latestVersion(string $missionId): ?array
    {
        $rows = $this->db->rows('SELECT * FROM mission_version WHERE company_id=? AND mission_id=? ORDER BY revision DESC LIMIT 1', [$this->access->company,$missionId]);
        if (!$rows) return null;
        $row = $rows[0];
        $row['snapshot'] = json_decode($row['snapshot_json'],true,512,JSON_THROW_ON_ERROR);
        return $row;
    }

    private function workCopy(array $mission,bool $includeWithdrawn): array
    {
        $assignments = $this->db->rows('SELECT a.*,p.first_name,p.last_name,p.account_uid FROM mission_assignment a JOIN person p ON p.id=a.person_id AND p.company_id=a.company_id WHERE a.company_id=? AND a.mission_id=? ORDER BY p.last_name,p.first_name,a.id', [$this->access->company,$mission['id']]);
        $days = $this->db->rows('SELECT * FROM mission_day WHERE company_id=? AND mission_id=? ORDER BY day,position,id', [$this->access->company,$mission['id']]);
        $byAssignment = [];
        foreach ($days as $day) $byAssignment[$day['assignment_id']][] = ['day'=>$day['day'],'starts_at'=>$day['starts_at'],'ends_at'=>$day['ends_at'],'break_minutes'=>(int)$day['break_minutes'],'position'=>(int)$day['position']];
        $result = [];
        foreach ($assignments as $assignment) {
            // Only this management projection may expose private membership edits.
            $assignment['state'] = (int)$assignment['work_withdrawn']===1 ? 'withdrawn' : ($assignment['state']==='withdrawn' ? 'pending' : $assignment['state']);
            if (!$includeWithdrawn && $assignment['state']==='withdrawn') continue;
            $assignment['days'] = $byAssignment[$assignment['id']] ?? [];
            $result[] = $assignment;
        }
        return [
            'assignments'=>$result,
            'requirements'=>$this->db->rows('SELECT * FROM mission_requirement WHERE company_id=? AND mission_id=? AND superseded_at IS NULL ORDER BY position,id', [$this->access->company,$mission['id']]),
            'resources'=>$this->db->rows('SELECT * FROM mission_resource WHERE company_id=? AND mission_id=? AND superseded_at IS NULL ORDER BY position,id', [$this->access->company,$mission['id']]),
        ];
    }

    private function snapshotFrom(array $mission,array $assignments,array $requirements,array $resources): array
    {
        $missionPart = [
            'manager_name'=>$this->managerName($mission),
            'company_name'=>(string)($this->db->rows('SELECT name FROM company WHERE id=?',[$this->access->company])[0]['name'] ?? ''),
            'id'=>$mission['id'],
            'reference'=>$mission['reference'],
            'title'=>$mission['title'],
            'affair_id'=>$mission['affair_id'],
            'affair_reference'=>$mission['affair_reference'],
            'affair_label'=>$mission['affair_label'],
            'client_label'=>$mission['client_label'],
            'nextcloud_url'=>$mission['nextcloud_url'],
            'site_label'=>$mission['site_label'],
            'starts_on'=>$mission['starts_on'],
            'ends_on'=>$mission['ends_on'],
            'timezone'=>$mission['timezone'],
            'instructions'=>$mission['instructions'],
            'risks'=>$mission['risks'],
            'epi'=>$mission['epi'],
        ];
        $requirementsPart = [];
        foreach ($requirements as $requirement) {
            $requirementsPart[] = ['kind'=>$requirement['kind'],'label'=>$requirement['label'],'mandatory'=>(int)$requirement['mandatory'],'status'=>'declared','note'=>(string)$requirement['note'],'position'=>(int)$requirement['position']];
        }
        $resourcesPart = [];
        foreach ($resources as $resource) {
            $resourcesPart[] = [
                'id'=>(int)$resource['id'],
                'kind'=>$resource['kind'],
                'title'=>$resource['title'],
                'url'=>$resource['url'],
                'required_reading'=>(int)$resource['required_reading'],
                'mime'=>(string)$resource['mime'],
                'bytes'=>$resource['bytes']===null?null:(int)$resource['bytes'],
                'sha256'=>(string)$resource['sha256'],
                'position'=>(int)$resource['position'],
            ];
        }
        $assignmentPart = [];
        foreach ($assignments as $assignment) {
            if ($assignment['state']==='withdrawn') continue;
            $normalizedDays = [];
            foreach ($assignment['days'] as $day) $normalizedDays[] = ['day'=>$day['day'],'starts_at'=>$day['starts_at'],'ends_at'=>$day['ends_at'],'break_minutes'=>(int)$day['break_minutes'],'position'=>(int)($day['position'] ?? 0)];
            $assignmentPart[] = [
                'id'=>$assignment['id'],
                'person_id'=>$assignment['person_id'],
                'first_name'=>$assignment['first_name'],
                'last_name'=>$assignment['last_name'],
                'role_label'=>$assignment['role_label'],
                'state'=>$assignment['state'],
                'content_hash'=>$this->assignmentHash($missionPart,['role_label'=>$assignment['role_label'],'days'=>$normalizedDays],$requirementsPart,$resourcesPart),
                'days'=>$normalizedDays,
            ];
        }
        usort($assignmentPart,static fn(array $a,array $b): int => [$a['person_id'],$a['id']] <=> [$b['person_id'],$b['id']]);
        usort($requirementsPart,static fn(array $a,array $b): int => [$a['position'],$a['label']] <=> [$b['position'],$b['label']]);
        usort($resourcesPart,static fn(array $a,array $b): int => [$a['position'],$a['id']] <=> [$b['position'],$b['id']]);
        $snapshot = ['mission'=>$missionPart,'assignments'=>$assignmentPart,'requirements'=>$requirementsPart,'resources'=>$resourcesPart];
        // L'état d'acceptation et les identifiants de lignes ne font pas partie du
        // contenu opérationnel : ils ne doivent pas changer l'empreinte globale.
        $hashPayload = $snapshot;
        foreach ($hashPayload['assignments'] as &$assignmentHashRow) unset($assignmentHashRow['state']);
        unset($assignmentHashRow);
        foreach ($hashPayload['resources'] as &$resourceHashRow) unset($resourceHashRow['id']);
        unset($resourceHashRow);
        $snapshot['content_hash'] = $this->hashJson($hashPayload);
        return $snapshot;
    }

    private function assignmentHash(array $mission,array $assignment,array $requirements,array $resources): string
    {
        $mandatoryRequirements = [];
        foreach ($requirements as $requirement) if ((int)$requirement['mandatory']===1) $mandatoryRequirements[] = ['kind'=>$requirement['kind'],'label'=>$requirement['label'],'note'=>$requirement['note']];
        $requiredResources = [];
        foreach ($resources as $resource) if ((int)$resource['required_reading']===1) $requiredResources[] = ['kind'=>$resource['kind'],'title'=>$resource['title'],'url'=>$resource['url'],'sha256'=>$resource['sha256']];
        usort($mandatoryRequirements,static fn(array $a,array $b): int => [$a['kind'],$a['label'],$a['note']] <=> [$b['kind'],$b['label'],$b['note']]);
        usort($requiredResources,static fn(array $a,array $b): int => [$a['kind'],$a['title'],$a['url'] ?? '',$a['sha256']] <=> [$b['kind'],$b['title'],$b['url'] ?? '',$b['sha256']]);
        return $this->hashJson(['mission'=>$mission,'assignment'=>$assignment,'requirements'=>$mandatoryRequirements,'resources'=>$requiredResources]);
    }

    private function hashJson(array $value): string
    {
        return hash('sha256',json_encode($value,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    private function summary(array $assignments): array
    {
        $summary = ['total'=>0,'accepted'=>0,'pending'=>0,'refused'=>0,'withdrawn'=>0,'acceptance'=>'none'];
        foreach ($assignments as $assignment) {
            $state = (string)$assignment['state'];
            if ($state==='withdrawn') { $summary['withdrawn']++; continue; }
            $summary['total']++;
            if (isset($summary[$state])) $summary[$state]++;
        }
        if ($summary['total']===0) $summary['acceptance'] = 'none';
        elseif ($summary['accepted']===$summary['total']) $summary['acceptance'] = 'complete';
        elseif ($summary['accepted']>0) $summary['acceptance'] = 'partial';
        elseif ($summary['refused']>0 && $summary['pending']===0) $summary['acceptance'] = 'refused';
        else $summary['acceptance'] = 'pending';
        return $summary;
    }

    private function decorate(array $mission): array
    {
        $work = $this->workCopy($mission,true);
        $latest = $this->latestVersion($mission['id']);
        $snapshot = $this->snapshotFrom($mission,$work['assignments'],$work['requirements'],$work['resources']);
        $mission['summary'] = $this->summary($work['assignments']);
        $mission['latest_revision'] = (int)($latest['revision'] ?? 0);
        $mission['unpublished'] = $latest === null || !hash_equals((string)$latest['content_hash'],(string)$snapshot['content_hash']);
        $mission['editable'] = $this->editable($mission);
        return $mission;
    }

    private function conflictsFrom(array $assignments,string $excludeMissionId): array
    {
        $otherMissions = $this->db->rows("SELECT m.id,m.reference,m.title,m.site_label,v.snapshot_json FROM mission_version v JOIN mission m ON m.id=v.mission_id AND m.company_id=v.company_id WHERE m.company_id=? AND m.id<>? AND m.status='published' AND m.current_revision>0 AND v.revision=m.current_revision", [$this->access->company,$excludeMissionId]);
        $conflicts = [];
        foreach ($assignments as $assignment) {
            if ($assignment['state']==='withdrawn') continue;
            foreach ($assignment['days'] as $day) {
                foreach ($otherMissions as $other) {
                    $snapshot = json_decode($other['snapshot_json'],true,512,JSON_THROW_ON_ERROR);
                    foreach ($snapshot['assignments'] as $otherAssignment) {
                        if (($otherAssignment['person_id'] ?? '') !== $assignment['person_id']) continue;
                        foreach ($otherAssignment['days'] as $otherDay) {
                            if ($otherDay['day'] !== $day['day']) continue;
                            if ($this->minutes($day['starts_at']) < $this->minutes($otherDay['ends_at']) && $this->minutes($otherDay['starts_at']) < $this->minutes($day['ends_at'])) {
                                $conflicts[] = [
                                    'person_id'=>$assignment['person_id'],
                                    'person_name'=>trim($assignment['first_name'].' '.$assignment['last_name']),
                                    'day'=>$day['day'],
                                    'starts_at'=>$day['starts_at'],
                                    'ends_at'=>$day['ends_at'],
                                    'other_starts_at'=>$otherDay['starts_at'],
                                    'other_ends_at'=>$otherDay['ends_at'],
                                    'mission_id'=>$other['id'],
                                    'mission_reference'=>$other['reference'],
                                    'mission_title'=>$other['title'],
                                    'site_label'=>$other['site_label'],
                                ];
                            }
                        }
                    }
                }
            }
        }
        return $conflicts;
    }

    private function assertPublishable(array $mission,array $work): void
    {
        foreach (['affair_reference','affair_label','title','site_label','starts_on','ends_on','instructions','risks','epi'] as $field) {
            if (trim((string)$mission[$field])==='') throw new \DomainException('Publication impossible : le champ « '.$field.' » est obligatoire.');
        }
        if ($mission['ends_on'] < $mission['starts_on']) throw new \DomainException('Publication impossible : période invalide.');
        $active = array_values(array_filter($work['assignments'],static fn(array $assignment): bool => $assignment['state']!=='withdrawn'));
        if (!$active) throw new \DomainException('Publication impossible : aucun équipier affecté.');
        foreach ($active as $assignment) {
            if (!$assignment['days']) throw new \DomainException('Publication impossible : aucun créneau pour '.$assignment['first_name'].' '.$assignment['last_name'].'.');
            $person = $this->db->rows('SELECT id,status,account_uid FROM person WHERE company_id=? AND id=?', [$this->access->company,$assignment['person_id']])[0] ?? null;
            if ($person === null || $person['status']!=='active') throw new \DomainException('Publication impossible : '.$assignment['first_name'].' '.$assignment['last_name'].' n’est plus actif.');
            if ((string)($person['account_uid'] ?? '')==='') throw new \DomainException('Publication impossible : '.$assignment['first_name'].' '.$assignment['last_name'].' n’a pas de compte lié.');
            if ($this->db->authority()->eligible($this->access->company,(string)$person['account_uid'])===null) throw new \DomainException('Publication impossible : le compte de '.$assignment['first_name'].' '.$assignment['last_name'].' n’est pas habilité.');
        }
        $conflicts = $this->conflictsFrom($active,$mission['id']);
        if ($conflicts) {
            $conflict = $conflicts[0];
            throw new \DomainException('Publication impossible : chevauchement pour '.$conflict['person_name'].' le '.$conflict['day'].' avec la mission '.$conflict['mission_reference'].'.');
        }
    }

    private function normalizeMission(array $input,?array $before,array $affair): array
    {
        if ($before !== null && array_diff(array_keys($input),['affair_id','title','site_label','starts_on','ends_on','timezone','instructions','risks','epi','internal_note','nextcloud_url','assignments','requirements','resources'])) {
            throw new \InvalidArgumentException('Champ de mission non autorisé.');
        }
        $value = fn(string $key,string $default=''): string => array_key_exists($key,$input) ? (is_string($input[$key]) ? $input[$key] : throw new \InvalidArgumentException('Champ de mission invalide.')) : $default;
        $title = $this->line($value('title',(string)($before['title'] ?? '')),180,true);
        $site = $this->line($value('site_label',(string)($before['site_label'] ?? '')),180,true);
        $starts = $this->dateValue($value('starts_on',(string)($before['starts_on'] ?? '')));
        $ends = $this->dateValue($value('ends_on',(string)($before['ends_on'] ?? '')));
        if ($ends < $starts) throw new \InvalidArgumentException('La date de fin doit suivre la date de début.');
        $timezone = $value('timezone',(string)($before['timezone'] ?? self::TIMEZONE));
        if ($timezone !== self::TIMEZONE) throw new \InvalidArgumentException('Fuseau de mission invalide.');
        $instructions = $this->multiline($value('instructions',(string)($before['instructions'] ?? '')),10000,false);
        $risks = $this->multiline($value('risks',(string)($before['risks'] ?? '')),10000,false);
        $epi = $this->multiline($value('epi',(string)($before['epi'] ?? '')),5000,false);
        $note = $this->multiline($value('internal_note',(string)($before['internal_note'] ?? '')),5000,false);
        $affairChanged = $before === null || $before['affair_id'] !== $affair['id'];
        $defaultUrl = $affairChanged ? ($affair['nextcloud_folder_url'] ?? null) : ($before['nextcloud_url'] ?? null);
        $nextcloud = array_key_exists('nextcloud_url',$input) ? trim($value('nextcloud_url')) : (string)($defaultUrl ?? '');
        $nextcloud = $nextcloud === '' ? null : AffairService::externalUrl($nextcloud);
        return [
            'affair_reference'=>$affairChanged ? $affair['reference'] : (string)$before['affair_reference'],
            'affair_label'=>$affairChanged ? $affair['label'] : (string)$before['affair_label'],
            'client_label'=>$affairChanged ? $affair['client_label'] : (string)$before['client_label'],
            'nextcloud_url'=>$nextcloud,
            'title'=>$title,
            'site_label'=>$site,
            'starts_on'=>$starts,
            'ends_on'=>$ends,
            'timezone'=>$timezone,
            'instructions'=>$instructions,
            'risks'=>$risks,
            'epi'=>$epi,
            'internal_note'=>$note,
        ];
    }

    private function replaceAssignments(array $mission,array $input): void
    {
        if (!is_array($input)) throw new \InvalidArgumentException('Affectations invalides.');
        if (count($input)>100) throw new \InvalidArgumentException('Trop d’affectations.');
        $existing = [];
        foreach ($this->db->rows('SELECT * FROM mission_assignment WHERE company_id=? AND mission_id=?', [$this->access->company,$mission['id']]) as $row) $existing[$row['person_id']] = $row;
        $seen = [];
        $now = gmdate('c');
        foreach ($input as $key=>$assignment) {
            if (!is_array($assignment)) throw new \InvalidArgumentException('Affectation invalide.');
            $personId = (string)($assignment['person_id'] ?? (is_string($key) ? $key : ''));
            if (!Uuid::valid($personId) || isset($seen[$personId])) throw new \InvalidArgumentException('Équipier invalide ou en double.');
            $seen[$personId] = true;
            $person = $this->db->rows('SELECT id,status,account_uid FROM person WHERE company_id=? AND id=?', [$this->access->company,$personId])[0] ?? null;
            if ($person === null) throw new \InvalidArgumentException('Équipier inconnu.');
            $role = $this->line((string)($assignment['role_label'] ?? 'Équipier'),80,true);
            $days = $this->normalizeDays($assignment['days'] ?? [],$mission);
            if (isset($existing[$personId])) {
                $row = $existing[$personId];
                $this->db->execute('UPDATE mission_assignment SET role_label=?,work_withdrawn=0,updated_at=? WHERE company_id=? AND id=?',
                    [$role,$now,$this->access->company,$row['id']]);
                $assignmentId = $row['id'];
            } else {
                $assignmentId = Uuid::v4();
                $this->db->execute('INSERT INTO mission_assignment(id,company_id,mission_id,person_id,role_label,state,content_hash,accepted_version_id,accepted_at,refused_at,refusal_reason,created_at,updated_at) VALUES (?,?,?,?,?,?,?,NULL,NULL,NULL,NULL,?,?)',
                    [$assignmentId,$this->access->company,$mission['id'],$personId,$role,'pending','',$now,$now]);
            }
            $this->db->execute('DELETE FROM mission_day WHERE company_id=? AND assignment_id=?', [$this->access->company,$assignmentId]);
            foreach ($days as $position=>$day) {
                $this->db->execute('INSERT INTO mission_day(company_id,mission_id,assignment_id,day,starts_at,ends_at,break_minutes,position) VALUES (?,?,?,?,?,?,?,?)',
                    [$this->access->company,$mission['id'],$assignmentId,$day['day'],$day['starts_at'],$day['ends_at'],$day['break_minutes'],$position]);
            }
        }
        foreach ($existing as $personId=>$row) {
            if (isset($seen[$personId])) continue;
            $this->db->execute('UPDATE mission_assignment SET work_withdrawn=1,updated_at=? WHERE company_id=? AND id=?', [$now,$this->access->company,$row['id']]);
            $this->db->execute('DELETE FROM mission_day WHERE company_id=? AND assignment_id=?', [$this->access->company,$row['id']]);
        }
    }

    private function normalizeDays(array $input,array $mission): array
    {
        if (count($input)>400) throw new \InvalidArgumentException('Trop de journées planifiées.');
        $days = [];
        foreach ($input as $day) {
            if (!is_array($day)) throw new \InvalidArgumentException('Journée invalide.');
            $date = $this->dateValue((string)($day['day'] ?? ''));
            if ($date < $mission['starts_on'] || $date > $mission['ends_on']) throw new \InvalidArgumentException('Une journée est hors de la période de la mission.');
            if (isset($days[$date])) throw new \InvalidArgumentException('Un seul créneau continu est autorisé par jour et par équipier.');
            $starts = $this->timeValue((string)($day['starts_at'] ?? ''));
            $ends = $this->timeValue((string)($day['ends_at'] ?? ''),true);
            if ($this->minutes($ends) <= $this->minutes($starts)) throw new \InvalidArgumentException('L’heure de fin doit suivre l’heure de début ; un créneau nocturne est découpé sur deux jours.');
            $break = $day['break_minutes'] ?? 0;
            if (!is_int($break) && !(is_string($break) && ctype_digit($break))) throw new \InvalidArgumentException('Pause invalide.');
            $break = (int)$break;
            if ($break < 0 || $break % 30 !== 0 || $break >= $this->minutes($ends)-$this->minutes($starts)) throw new \InvalidArgumentException('La pause doit être un multiple de 30 minutes et rester inférieure au créneau.');
            $days[$date] = ['day'=>$date,'starts_at'=>$starts,'ends_at'=>$ends,'break_minutes'=>$break];
        }
        ksort($days);
        return array_values($days);
    }

    private function replaceRequirements(array $mission,array $input): void
    {
        if (!is_array($input)) throw new \InvalidArgumentException('Prérequis invalides.');
        if (count($input)>100) throw new \InvalidArgumentException('Trop de prérequis.');
        $now = gmdate('c');
        $this->db->execute('UPDATE mission_requirement SET superseded_at=? WHERE company_id=? AND mission_id=? AND superseded_at IS NULL', [$now,$this->access->company,$mission['id']]);
        $position = 0;
        foreach ($input as $requirement) {
            if (!is_array($requirement)) throw new \InvalidArgumentException('Prérequis invalide.');
            $kind = (string)($requirement['kind'] ?? 'other');
            if (!in_array($kind,self::REQUIREMENT_KINDS,true)) throw new \InvalidArgumentException('Nature de prérequis invalide.');
            $label = $this->line((string)($requirement['label'] ?? ''),180,true);
            $mandatory = $this->boolean($requirement['mandatory'] ?? false);
            $note = $this->multiline((string)($requirement['note'] ?? ''),1000,false);
            $this->db->execute('INSERT INTO mission_requirement(company_id,mission_id,kind,label,mandatory,status,reference_uid,note,position,created_at,superseded_at) VALUES (?,?,?,?,?,?,?,?,?,?,NULL)',
                [$this->access->company,$mission['id'],$kind,$label,$mandatory?1:0,'declared',null,$note,$position++,gmdate('c')]);
        }
    }

    private function replaceExternalResources(array $mission,array $input): void
    {
        if (!is_array($input)) throw new \InvalidArgumentException('Ressources invalides.');
        if (count($input)>100) throw new \InvalidArgumentException('Trop de ressources.');
        $now = gmdate('c');
        $this->db->execute("UPDATE mission_resource SET superseded_at=? WHERE company_id=? AND mission_id=? AND kind='external_url' AND superseded_at IS NULL", [$now,$this->access->company,$mission['id']]);
        $position = 0;
        foreach ($input as $resource) {
            if (!is_array($resource)) throw new \InvalidArgumentException('Ressource invalide.');
            $title = $this->line((string)($resource['title'] ?? ''),180,true);
            $url = AffairService::externalUrl((string)($resource['url'] ?? ''));
            $required = $this->boolean($resource['required_reading'] ?? false);
            $this->db->execute("INSERT INTO mission_resource(company_id,mission_id,kind,title,url,storage_name,mime,bytes,sha256,required_reading,position,created_at,superseded_at) VALUES (?,?,? ,?,?,NULL,'',NULL,'',?,?,?,NULL)",
                [$this->access->company,$mission['id'],'external_url',$title,$url,$required?1:0,$position++,gmdate('c')]);
        }
    }

    private function generateOrder(array $mission,array $latest,array $assignmentSnapshot,string $acceptedAt): int
    {
        $code = strtoupper(bin2hex(random_bytes(6)));
        $code = substr($code,0,4).'-'.substr($code,4,4).'-'.substr($code,8,4);
        $generatedAt = gmdate('c');
        $storage = 'orders/'.$this->access->company.'/'.bin2hex(random_bytes(16)).'.pdf';
        $path = $this->privatePath($storage,false);
        $view = $this->pdfView($mission,$latest['snapshot'],$assignmentSnapshot,['revision'=>(int)$latest['revision'],'created_at'=>$latest['created_at']],['verification_code'=>$code,'generated_at'=>$generatedAt],$acceptedAt);
        try {
            $pdf = (new MissionPdf())->render($view,$view['assignment'],false);
            $this->ensureDirectory(dirname($path));
            if (file_put_contents($path,$pdf,LOCK_EX) !== strlen($pdf)) throw new \RuntimeException('Écriture de l’ordre de mission impossible.');
            chmod($path,0600);
            $sha = hash('sha256',$pdf);
            $this->db->execute('INSERT INTO mission_order_document(company_id,mission_id,assignment_id,version_id,content_hash,storage_name,sha256,verification_code,generated_at,superseded_at,voided_at) VALUES (?,?,?,?,?,?,?,?,?,NULL,NULL)',
                [$this->access->company,$mission['id'],$assignmentSnapshot['id'],$latest['id'],$assignmentSnapshot['content_hash'],$storage,$sha,$code,$generatedAt]);
            $id = (int)$this->db->pdo->lastInsertId();
            $this->db->execute('UPDATE mission_order_document SET superseded_at=? WHERE company_id=? AND assignment_id=? AND id<>? AND superseded_at IS NULL', [$generatedAt,$this->access->company,$assignmentSnapshot['id'],$id]);
            $this->audit($mission['id'],'generate_order',(int)$latest['revision'],['assignment'=>$assignmentSnapshot['id'],'document'=>$id]);
            return $id;
        } catch (\Throwable $error) {
            if (is_file($path)) @unlink($path);
            throw $error;
        }
    }

    private function pdfView(array $mission,array $snapshot,array $assignment,array $version,?array $order,string $acceptedAt=''): array
    {
        $assignment['accepted_at'] = $acceptedAt !== '' ? $acceptedAt : (string)($assignment['accepted_at'] ?? '');
        return [
            'mission'=>$snapshot['mission'],
            'version'=>$version,
            'assignment'=>$assignment,
            'requirements'=>$snapshot['requirements'],
            'resources'=>$snapshot['resources'],
            'company_name'=>(string)($snapshot['mission']['company_name'] ?? 'Non figée — nouvelle publication nécessaire'),
            'manager_name'=>(string)($snapshot['mission']['manager_name'] ?? 'Non figé — nouvelle publication nécessaire'),
            'order'=>$order ?? [],
        ];
    }

    private function managerName(array $mission): string
    {
        $rows = $this->db->rows('SELECT p.first_name,p.last_name FROM affair a JOIN person p ON p.id=a.manager_person_id AND p.company_id=a.company_id WHERE a.company_id=? AND a.id=?', [$this->access->company,$mission['affair_id']]);
        if ($rows) return trim($rows[0]['first_name'].' '.$rows[0]['last_name']);
        return (string)$mission['created_by_uid'];
    }

    private function affairManagerUid(array $mission): ?string
    {
        $rows = $this->db->rows('SELECT p.account_uid FROM affair a JOIN person p ON p.id=a.manager_person_id AND p.company_id=a.company_id WHERE a.company_id=? AND a.id=?', [$this->access->company,$mission['affair_id']]);
        $uid = $rows[0]['account_uid'] ?? null;
        return is_string($uid) && $uid !== '' ? $uid : null;
    }

    private function notifyAffairManager(array $mission,string $title,string $body,?string $event=null): void
    {
        $uid = $this->affairManagerUid($mission);
        if ($uid !== null) (new JourneyContext($this->db,$this->access))->notify($title,$body,[],$uid,$event);
    }

    private function audit(string $missionId,string $action,?int $revision,array $details=[]): void
    {
        $this->db->execute('INSERT INTO mission_audit(company_id,mission_id,actor_uid,action,revision,details_json,created_at) VALUES (?,?,?,?,?,?,?)',
            [$this->access->company,$missionId,$this->access->uid,$action,$revision,json_encode($details,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),gmdate('c')]);
    }

    private function nextReference(): string
    {
        $year = (new \DateTimeImmutable('now',new \DateTimeZone(self::TIMEZONE)))->format('Y');
        for ($index=1;$index<=9999;$index++) {
            $reference = 'M-'.$year.'-'.str_pad((string)$index,4,'0',STR_PAD_LEFT);
            if (!$this->db->rows('SELECT id FROM mission WHERE company_id=? AND reference=?', [$this->access->company,$reference])) return $reference;
        }
        throw new \RuntimeException('Référence de mission indisponible.');
    }

    private function changedFields(array $values,array $mission): array
    {
        $fields = [];
        foreach (['affair_reference','affair_label','client_label','title','site_label','starts_on','ends_on','instructions','risks','epi','internal_note','nextcloud_url'] as $field) {
            if ((string)($values[$field] ?? '') !== (string)($mission[$field] ?? '')) $fields[] = $field;
        }
        return $fields;
    }

    private function line(string $value,int $max,bool $required=false): string
    {
        $value = trim($value);
        if (mb_strlen($value)>$max || preg_match('/[\x00-\x1F\x7F]/u',$value)) throw new \InvalidArgumentException('Texte invalide ou trop long.');
        if ($required && $value==='') throw new \InvalidArgumentException('Un champ obligatoire est vide.');
        return $value;
    }

    private function multiline(string $value,int $max,bool $required=false): string
    {
        $value = trim($value);
        if (mb_strlen($value)>$max || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u',$value)) throw new \InvalidArgumentException('Texte invalide ou trop long.');
        if ($required && $value==='') throw new \InvalidArgumentException('Un champ obligatoire est vide.');
        return $value;
    }

    private function dateValue(string $value): string
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d',$value);
        if ($date === false || $date->format('Y-m-d') !== $value) throw new \InvalidArgumentException('Date invalide.');
        return $value;
    }

    private function timeValue(string $value,bool $dayEnd=false): string
    {
        if ($dayEnd && $value==='24:00') return $value;
        if (!preg_match('/^([01][0-9]|2[0-3]):(00|30)$/D',$value)) throw new \InvalidArgumentException('Les horaires doivent être à la demi-heure (00 ou 30).');
        return $value;
    }

    private function minutes(string $value): int
    {
        [$hours,$minutes] = array_map('intval',explode(':',$value));
        return $hours*60+$minutes;
    }

    private function boolean(mixed $value): bool
    {
        return in_array($value,[true,1,'1','on','yes'],true);
    }

    private function privatePath(string $storage,bool $mustExist=true): string
    {
        if (!preg_match('#^(orders|resources)/[0-9]+/[a-f0-9]{32}\.(pdf|png|jpg|webp|txt)$#D',$storage)) throw new \DomainException('Fichier privé invalide.');
        $root = $this->db->directory.'/missions';
        if (!is_dir($root)) {
            if ($mustExist) throw new \DomainException('Fichier privé indisponible.');
            $this->ensureDirectory($root);
        }
        $rootReal = realpath($root);
        if ($rootReal === false) throw new \DomainException('Fichier privé indisponible.');
        if (!$mustExist) return $rootReal.'/'.$storage;
        $real = realpath($rootReal.'/'.$storage);
        if ($real === false || !str_starts_with($real,$rootReal.'/')) throw new \DomainException('Fichier privé indisponible.');
        return $real;
    }

    private function ensureDirectory(string $directory): void
    {
        if (is_dir($directory)) return;
        if (!mkdir($directory,0700,true) && !is_dir($directory)) throw new \RuntimeException('Stockage privé indisponible.');
        chmod($directory,0700);
    }
}
