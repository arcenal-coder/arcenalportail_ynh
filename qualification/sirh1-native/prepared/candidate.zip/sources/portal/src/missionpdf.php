<?php
// SPDX-License-Identifier: GPL-3.0-or-later
declare(strict_types=1);
namespace Vigilance;

/**
 * Minimal, dependency-free PDF writer for mission orders.
 * Standard Helvetica fonts, WinAnsi encoding, no compression so the document
 * remains inspectable by the integrity tests. No external library is loaded.
 */
final class MissionPdf
{
    private const WIDTH = 595.28;
    private const HEIGHT = 841.89;
    private const MARGIN = 46.0;
    private array $pages = [];
    private string $content = '';
    private float $y = 0.0;
    private int $page = 0;

    public function render(array $view, array $assignment, bool $draft = false): string
    {
        $mission = $view['mission'];
        $this->newPage();
        if ($draft) $this->watermark('BROUILLON');
        $this->line('ORDRE DE MISSION', 20, true, '#9d3d25');
        $this->line($mission['reference'].' · version '.$view['version']['revision'], 11, true);
        $this->spacer(6);
        $this->line($draft ? 'Document de travail — non publié, sans valeur d’acceptation.' : 'Document généré après acceptation de l’équipier.', 9, false, '#64748b');
        $this->spacer(10);

        $this->section('Destinataire');
        $this->field('Équipier', $assignment['first_name'].' '.$assignment['last_name']);
        $this->field('Rôle', $assignment['role_label']);
        $this->field('Entreprise', (string) ($view['company_name'] ?? ''));
        $this->field('Affaire', trim($mission['affair_reference'].' — '.$mission['affair_label'],' —'));
        if (($mission['client_label'] ?? '') !== '') $this->field('Client', $mission['client_label']);
        $this->field('Site', $mission['site_label']);
        $this->field('Période', self::dateFr($mission['starts_on']).' au '.self::dateFr($mission['ends_on']));

        $this->section('Jours et horaires');
        if (!$assignment['days']) {
            $this->line('Aucun créneau défini.', 10);
        } else {
            foreach ($assignment['days'] as $day) {
                $pause = (int) $day['break_minutes'] > 0 ? ' · pause '.((int) $day['break_minutes']).' min' : '';
                $this->line(self::dateFr($day['day']).'  '.$day['starts_at'].'–'.$day['ends_at'].$pause, 10);
            }
        }

        $this->section('Consignes, risques et EPI');
        $this->paragraph('Consignes', $mission['instructions']);
        $this->paragraph('Risques connus', $mission['risks']);
        $this->paragraph('EPI requis', $mission['epi']);

        $this->section('Prérequis déclarés — non vérifiés');
        if (!$view['requirements']) {
            $this->line('Aucun prérequis déclaré.', 10);
        } else {
            foreach ($view['requirements'] as $requirement) {
                $flag = (int) $requirement['mandatory'] === 1 ? 'Déclaré obligatoire' : 'Informatif';
                $this->line('• '.$requirement['label'].' ('.$flag.', non vérifié)', 9);
                if (trim((string) $requirement['note']) !== '') $this->line('  '.$requirement['note'], 8, false, '#64748b');
            }
        }
        $this->line('Ces prérequis sont déclaratifs dans l’incrément 1. Aucun contrôle bloquant ni conformité n’est affirmé.', 8, false, '#64748b');

        $this->section('Ressources et documents');
        if (($mission['nextcloud_url'] ?? '') !== '') $this->line('Dossier d’affaire Nextcloud : '.$mission['nextcloud_url'], 8);
        if (!$view['resources']) {
            $this->line('Aucune ressource de mission.', 10);
        } else {
            foreach ($view['resources'] as $resource) {
                $required = (int) $resource['required_reading'] === 1 ? ' — lecture requise' : '';
                $this->line('• '.$resource['title'].$required, 9);
                if ($resource['kind'] === 'external_url' && ($resource['url'] ?? '') !== '') $this->line('  '.$resource['url'], 8, false, '#64748b');
                if ($resource['kind'] === 'internal_file') $this->line('  Fichier interne privé, consultable dans VIGILance.', 8, false, '#64748b');
            }
        }

        $this->section('Acceptation et vérification');
        if ($draft) {
            $this->field('Acceptation', 'Non applicable — brouillon');
        } else {
            $this->field('Acceptation', ($assignment['accepted_at'] ?? '') !== '' ? self::dateTimeFr($assignment['accepted_at']) : 'Non acceptée');
            $this->field('Empreinte du contenu', (string) $assignment['content_hash']);
            $this->field('Code de vérification', (string) ($view['order']['verification_code'] ?? ''));
        }
        $this->field('Version publiée', (string) $view['version']['revision'].' — '.self::dateTimeFr($view['version']['created_at']));
        $this->field('Responsable', (string) ($view['manager_name'] ?? 'Non désigné'));
        $this->field('Document généré', self::dateTimeFr($view['order']['generated_at'] ?? gmdate('c')));
        $this->spacer(8);
        $this->line('Cet ordre ne prouve pas la présence. La feuille de présence client est un document distinct, issu du pointage validé.', 8, false, '#64748b');

        return $this->output();
    }

    private function newPage(): void
    {
        if ($this->page > 0) $this->pages[] = $this->content;
        $this->page++;
        $this->content = '';
        $this->y = self::HEIGHT - self::MARGIN;
        $this->textRaw('VIGILance', 8, false, self::MARGIN, 24, '#64748b');
        $this->textRaw('Propulsé par ARCenal OS', 8, false, self::WIDTH - self::MARGIN - 120, 24, '#64748b');
        $this->line('', 4);
    }

    private function ensure(float $needed): void
    {
        if ($this->y - $needed < self::MARGIN + 20) $this->newPage();
    }

    private function section(string $title): void
    {
        $this->ensure(28);
        $this->spacer(7);
        $this->line($title, 12, true, '#9d3d25');
        $this->line('', 1);
    }

    private function field(string $label, string $value): void
    {
        $this->ensure(15);
        $this->textRaw($label.' : ', 9, true, self::MARGIN, $this->y);
        $x = self::MARGIN + 112;
        $this->textWrapped($value, 9, false, $x, self::WIDTH - self::MARGIN - $x);
    }

    private function paragraph(string $label, string $value): void
    {
        $this->ensure(24);
        $this->line($label, 9, true);
        $this->textWrapped(trim($value) === '' ? 'Non renseigné.' : $value, 9, false, self::MARGIN, self::WIDTH - 2 * self::MARGIN);
        $this->spacer(4);
    }

    private function line(string $text, float $size = 10, bool $bold = false, string $color = '#1f2937'): void
    {
        $this->textWrapped($text, $size, $bold, self::MARGIN, self::WIDTH - 2 * self::MARGIN, $color);
    }

    private function spacer(float $height): void
    {
        $this->y -= $height;
    }

    private function textWrapped(string $text, float $size, bool $bold, float $x, float $width, string $color = '#1f2937'): void
    {
        foreach (preg_split('/\R/u', $text) ?: [''] as $paragraph) {
            $words = preg_split('/\s+/u', trim($paragraph)) ?: [''];
            $current = '';
            foreach ($words as $word) {
                $candidate = $current === '' ? $word : $current.' '.$word;
                if ($this->textWidth($candidate, $size, $bold) > $width && $current !== '') {
                    $this->ensure($size * 1.35);
                    $this->textRaw($current, $size, $bold, $x, $this->y, $color);
                    $this->y -= $size * 1.35;
                    $current = $word;
                } else {
                    $current = $candidate;
                }
            }
            $this->ensure($size * 1.35);
            $this->textRaw($current, $size, $bold, $x, $this->y, $color);
            $this->y -= $size * 1.35;
        }
    }

    private function textWidth(string $text, float $size, bool $bold): float
    {
        return mb_strlen($text, 'UTF-8') * $size * ($bold ? 0.54 : 0.50);
    }

    private function textRaw(string $text, float $size, bool $bold, float $x, float $y, string $color = '#1f2937'): void
    {
        [$r,$g,$b] = self::rgb($color);
        $encoded = self::pdfString($text);
        $this->content .= sprintf("BT %.3F %.3F %.3F rg /%s %.3F Tf 1 0 0 1 %.3F %.3F Tm (%s) Tj ET\n", $r, $g, $b, $bold ? 'F2' : 'F1', $size, $x, self::HEIGHT - $y, $encoded);
    }

    private function watermark(string $text): void
    {
        $this->content .= "q 0.88 0.88 0.88 rg BT /F2 58 Tf 0.707 0.707 -0.707 0.707 110 300 Tm (".self::pdfString($text).") Tj ET Q\n";
    }

    private function output(): string
    {
        if ($this->page > 0) $this->pages[] = $this->content;
        $objects = [];
        $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objects[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objects[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $kids = [];
        $next = 5;
        foreach ($this->pages as $index => $content) {
            $pageObject = $next++;
            $contentObject = $next++;
            $kids[] = $pageObject.' 0 R';
            $objects[$pageObject] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '.self::WIDTH.' '.self::HEIGHT.'] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '.$contentObject.' 0 R >>';
            $stream = $content;
            $objects[$contentObject] = '<< /Length '.strlen($stream)." >>\nstream\n".$stream.'endstream';
        }
        $objects[2] = '<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($this->pages).' /MediaBox [0 0 '.self::WIDTH.' '.self::HEIGHT.'] >>';
        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [];
        foreach ($objects as $number => $body) {
            $offsets[$number] = strlen($pdf);
            $pdf .= $number." 0 obj\n".$body."\nendobj\n";
        }
        $xref = strlen($pdf);
        $max = max(array_keys($objects));
        $pdf .= "xref\n0 ".($max + 1)."\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $pdf .= isset($offsets[$i]) ? sprintf("%010d 00000 n \n",$offsets[$i]) : "0000000000 65535 f \n";
        }
        $pdf .= "trailer\n<< /Size ".($max + 1)." /Root 1 0 R >>\nstartxref\n".$xref."\n%%EOF\n";
        return $pdf;
    }

    private static function pdfString(string $text): string
    {
        $encoded = @iconv('UTF-8','Windows-1252//TRANSLIT',$text);
        if ($encoded === false) $encoded = preg_replace('/[^\x20-\x7E]/','?',$text) ?? '';
        return str_replace(['\\','(',')',"\r","\n"], ['\\\\','\\(','\\)',' ',' '], $encoded);
    }

    private static function rgb(string $hex): array
    {
        $hex = ltrim($hex,'#');
        if (!preg_match('/^[a-f0-9]{6}$/iD',$hex)) return [0.12,0.16,0.22];
        return [hexdec(substr($hex,0,2))/255,hexdec(substr($hex,2,2))/255,hexdec(substr($hex,4,2))/255];
    }

    private static function dateFr(string $value): string
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d',$value);
        return $date ? $date->format('d/m/Y') : $value;
    }

    private static function dateTimeFr(string $value): string
    {
        try { return (new \DateTimeImmutable($value))->setTimezone(new \DateTimeZone('Europe/Paris'))->format('d/m/Y à H:i'); }
        catch (\Throwable $error) { return $value; }
    }
}
