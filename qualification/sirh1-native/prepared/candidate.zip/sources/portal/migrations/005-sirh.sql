-- SPDX-License-Identifier: GPL-3.0-or-later
-- Incrément 1 SIRH : affaires, planning, missions, acceptations et ordres de mission.
-- Migration additive : aucune table métier existante n'est supprimée.
-- journey_mail est reconstruite uniquement pour étendre la contrainte CHECK des
-- événements ; ses lignes existantes sont recopiées à l'identique.

CREATE TABLE affair (
 id TEXT PRIMARY KEY,
 company_id INTEGER NOT NULL REFERENCES company(id),
 reference TEXT NOT NULL,
 label TEXT NOT NULL,
 client_label TEXT NOT NULL DEFAULT '',
 site_label TEXT NOT NULL DEFAULT '',
 manager_person_id TEXT REFERENCES person(id),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','closed','archived')),
 external_system TEXT NOT NULL DEFAULT 'none' CHECK(external_system IN ('none','dolibarr')),
 external_ref TEXT,
 nextcloud_folder_url TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1,
 UNIQUE(company_id, reference)
);
CREATE UNIQUE INDEX affair_external_ref ON affair(company_id, external_system, external_ref)
 WHERE external_ref IS NOT NULL AND external_ref <> '';
CREATE INDEX affair_manager ON affair(company_id, manager_person_id, status);

CREATE TABLE mission (
 id TEXT PRIMARY KEY,
 company_id INTEGER NOT NULL REFERENCES company(id),
 reference TEXT NOT NULL,
 affair_id TEXT NOT NULL REFERENCES affair(id),
 affair_reference TEXT NOT NULL,
 affair_label TEXT NOT NULL,
 client_label TEXT NOT NULL DEFAULT '',
 nextcloud_url TEXT,
 title TEXT NOT NULL,
 site_label TEXT NOT NULL,
 starts_on TEXT NOT NULL,
 ends_on TEXT NOT NULL,
 timezone TEXT NOT NULL DEFAULT 'Europe/Paris',
 instructions TEXT NOT NULL DEFAULT '',
 risks TEXT NOT NULL DEFAULT '',
 epi TEXT NOT NULL DEFAULT '',
 internal_note TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','closed','cancelled')),
 current_revision INTEGER NOT NULL DEFAULT 0,
 revision INTEGER NOT NULL DEFAULT 1,
 created_by_uid TEXT NOT NULL,
 published_at TEXT,
 closed_at TEXT,
 cancelled_at TEXT,
 cancel_reason TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(company_id, reference)
);
CREATE INDEX mission_affair ON mission(company_id, affair_id, status);
CREATE INDEX mission_period ON mission(company_id, starts_on, ends_on, status);

CREATE TABLE mission_version (
 id TEXT PRIMARY KEY,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 revision INTEGER NOT NULL,
 content_hash TEXT NOT NULL,
 snapshot_json TEXT NOT NULL,
 reason TEXT NOT NULL CHECK(reason IN ('publication','major_change','membership_change','correction')),
 created_by_uid TEXT NOT NULL,
 created_at TEXT NOT NULL,
 UNIQUE(mission_id, revision)
);
CREATE INDEX mission_version_mission ON mission_version(mission_id, revision);

CREATE TABLE mission_assignment (
 id TEXT PRIMARY KEY,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 person_id TEXT NOT NULL REFERENCES person(id),
 role_label TEXT NOT NULL DEFAULT 'Équipier',
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','accepted','refused','withdrawn')),
 content_hash TEXT NOT NULL DEFAULT '',
 accepted_version_id TEXT REFERENCES mission_version(id),
 accepted_at TEXT,
 refused_at TEXT,
 refusal_reason TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(mission_id, person_id)
);
CREATE INDEX mission_assignment_person ON mission_assignment(company_id, person_id, state);
CREATE INDEX mission_assignment_mission ON mission_assignment(mission_id, state);

CREATE TABLE mission_day (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 assignment_id TEXT NOT NULL REFERENCES mission_assignment(id),
 day TEXT NOT NULL,
 starts_at TEXT NOT NULL,
 ends_at TEXT NOT NULL,
 break_minutes INTEGER NOT NULL DEFAULT 0 CHECK(break_minutes >= 0 AND break_minutes <= 720),
 position INTEGER NOT NULL DEFAULT 0,
 UNIQUE(assignment_id, day)
);
CREATE INDEX mission_day_mission ON mission_day(mission_id, day);
CREATE INDEX mission_day_assignment ON mission_day(assignment_id, day);

CREATE TABLE mission_acceptance (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 assignment_id TEXT NOT NULL REFERENCES mission_assignment(id),
 version_id TEXT NOT NULL REFERENCES mission_version(id),
 content_hash TEXT NOT NULL,
 decision TEXT NOT NULL CHECK(decision IN ('accepted','refused')),
 reason TEXT,
 decided_at TEXT NOT NULL,
 actor_uid TEXT NOT NULL,
 UNIQUE(assignment_id, version_id)
);
CREATE INDEX mission_acceptance_assignment ON mission_acceptance(assignment_id, id);
CREATE INDEX mission_acceptance_version ON mission_acceptance(version_id, decision);

CREATE TABLE mission_requirement (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 kind TEXT NOT NULL CHECK(kind IN ('qualification','document','briefing','other')),
 label TEXT NOT NULL,
 mandatory INTEGER NOT NULL DEFAULT 0 CHECK(mandatory IN (0,1)),
 status TEXT NOT NULL DEFAULT 'declared' CHECK(status IN ('declared','verified','waived')),
 reference_uid TEXT,
 note TEXT NOT NULL DEFAULT '',
 position INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,
 superseded_at TEXT
);
CREATE INDEX mission_requirement_mission ON mission_requirement(mission_id, superseded_at, position);

CREATE TABLE mission_resource (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 kind TEXT NOT NULL CHECK(kind IN ('internal_file','external_url')),
 title TEXT NOT NULL,
 url TEXT,
 storage_name TEXT,
 mime TEXT NOT NULL DEFAULT '',
 bytes INTEGER,
 sha256 TEXT NOT NULL DEFAULT '',
 required_reading INTEGER NOT NULL DEFAULT 0 CHECK(required_reading IN (0,1)),
 position INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,
 superseded_at TEXT
);
CREATE INDEX mission_resource_mission ON mission_resource(mission_id, superseded_at, position);

CREATE TABLE mission_resource_read (
 company_id INTEGER NOT NULL REFERENCES company(id),
 assignment_id TEXT NOT NULL REFERENCES mission_assignment(id),
 resource_id INTEGER NOT NULL REFERENCES mission_resource(id),
 read_at TEXT NOT NULL,
 PRIMARY KEY(assignment_id, resource_id)
);

CREATE TABLE mission_order_document (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 assignment_id TEXT NOT NULL REFERENCES mission_assignment(id),
 version_id TEXT NOT NULL REFERENCES mission_version(id),
 content_hash TEXT NOT NULL,
 storage_name TEXT NOT NULL,
 sha256 TEXT NOT NULL,
 verification_code TEXT NOT NULL,
 generated_at TEXT NOT NULL,
 superseded_at TEXT,
 voided_at TEXT,
 UNIQUE(assignment_id, version_id)
);
CREATE INDEX mission_order_assignment ON mission_order_document(assignment_id, id);
CREATE INDEX mission_order_mission ON mission_order_document(mission_id, id);

CREATE TABLE mission_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company_id INTEGER NOT NULL REFERENCES company(id),
 mission_id TEXT NOT NULL REFERENCES mission(id),
 actor_uid TEXT NOT NULL,
 action TEXT NOT NULL,
 revision INTEGER,
 details_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL
);
CREATE INDEX mission_audit_mission ON mission_audit(mission_id, id);

-- La file existante porte un CHECK limité aux événements de parcours. SQLite ne
-- sait pas modifier un CHECK en place : recopie exhaustive avant remplacement.
ALTER TABLE journey_mail RENAME TO journey_mail_legacy;
CREATE TABLE journey_mail (
 notification_id INTEGER PRIMARY KEY REFERENCES journey_notification(id),
 event TEXT NOT NULL CHECK(event IN (
  'candidate.opened','candidate.submitted','offer.published','offer.refused',
  'offer.accepted','welcome.completed','mission.published','mission.changed',
  'mission.cancelled','mission.accepted','mission.refused'
 )),
 required_roles TEXT NOT NULL DEFAULT '[]',
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','sent','cancelled','failed')),
 attempts INTEGER NOT NULL DEFAULT 0,
 available_at INTEGER NOT NULL DEFAULT 0,
 last_error TEXT NOT NULL DEFAULT '',
 sent_at TEXT
);
INSERT INTO journey_mail(notification_id,event,required_roles,state,attempts,available_at,last_error,sent_at)
 SELECT notification_id,event,required_roles,state,attempts,available_at,last_error,sent_at FROM journey_mail_legacy;
DROP TABLE journey_mail_legacy;
CREATE INDEX journey_mail_due ON journey_mail(state,available_at);
