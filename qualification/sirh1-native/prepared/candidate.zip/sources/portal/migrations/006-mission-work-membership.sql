-- Separate private work-copy membership from the last published response state.
-- Keep 005 checksums unchanged for databases already migrated in isolated tests.
ALTER TABLE mission_assignment ADD COLUMN work_withdrawn INTEGER NOT NULL DEFAULT 0 CHECK(work_withdrawn IN (0,1));
UPDATE mission_assignment SET work_withdrawn=1 WHERE state='withdrawn';
