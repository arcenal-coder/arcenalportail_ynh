# VIGILance pour YunoHost — candidate Preview 1.1.0-beta7~ynh3

Candidate locale de correction SIRH1, strictement supérieure à beta6, avec migrations005–006. Ni déployée ni qualifiée nativement ; sauvegarde/retour arrière et audit sécurité restent à qualifier. Voir `../../.arcenal/recette-sirh1/` pour les preuves et réserves ; les résultats beta5/L04 ci-dessous sont historiques et ne qualifient pas beta7.

VIGILance gère les dossiers collaborateurs, Mon dossier salarié, les permissions et les périmètres manager sans connexion à Dolibarr. L'identifiant historique installé `arcenalportail` est conservé.

Cette candidate ajoute les e-mails des workflows candidature/FORM S 13/accueil, avec file persistante, paramètres de destinataires et suivi/relance Administration. Les parcours réels, l'accueil vidéo/quiz/PDF, le thème Gratitude et la configuration Bridge sont préservés. Voir ../docs/VIGILANCE_WORKFLOW_EMAILS.md. La sélection configurable du domaine de logo et la projection automatique des groupes restent des travaux distincts.

À l'installation neuve, choisir le domaine, le chemin, le groupe SSO, le nom d'entreprise et un administrateur initial explicite. Aucun secret Dolibarr n'est demandé. Après une mise à jour historique, utiliser Configuration → Administrateur initial dans YunoHost pour sélectionner et initialiser le premier admin ; un admin existant ne peut pas être remplacé par cette action.

ARCenal Bridge conserve la propriété de config.php et de l'appairage QSSE historique. Les paramètres applicatifs VIGILance sont séparés dans application-settings.php ; les permissions Dolibarr ne sont jamais modifiées par ce paquet.

SQLite, configuration et logos sont privés, hors du dossier public. Le paquet inclut migrations, backup/restore avec snapshot cohérent et panneau d'amorçage. PHP CLI/SQLite sont déclarés comme dépendances pour une future installation ; le build ne les installe pas.

La branche preview du dépôt arcenalportail_ynh est destinée à la recette. Révision8156e1e : qualification native complète39326820575 réussie (12 scénarios, dont upgrade beta4 ynh2 et livraison MTA/Dovecot locale) ; beta5 promue dans le catalogue Preview par PR27/promotion39381489061, flux canonique et miroir vérifiés au niveau technique privé5. Réception cliente distincte, non exécutée ici. Les versions historiques beta1/beta2 au format non conforme exigent une réparation explicite avant upgrade ; l'outil tools/repair_installed_version.py fonctionne en simulation par défaut. Voir TEST_REPORT.md. Sources métier : https://github.com/arcenal-coder/arcenal-qsse.
